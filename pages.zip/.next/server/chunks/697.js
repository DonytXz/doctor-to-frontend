"use strict";
exports.id = 697;
exports.ids = [697];
exports.modules = {

/***/ 697:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _src_components_forms_theme_elements_CustomCheckbox__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6305);
/* harmony import */ var _src_components_forms_theme_elements_CustomTextField__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6001);
/* harmony import */ var _src_components_forms_theme_elements_CustomFormLabel__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9237);
/* harmony import */ var _AuthSocialButtons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2112);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _src_services_Auth__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5423);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6201);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7987);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _src_components_forms_theme_elements_CustomCheckbox__WEBPACK_IMPORTED_MODULE_3__, _src_components_forms_theme_elements_CustomTextField__WEBPACK_IMPORTED_MODULE_4__, _src_components_forms_theme_elements_CustomFormLabel__WEBPACK_IMPORTED_MODULE_5__, _AuthSocialButtons__WEBPACK_IMPORTED_MODULE_6__, _src_services_Auth__WEBPACK_IMPORTED_MODULE_8__, react_hot_toast__WEBPACK_IMPORTED_MODULE_9__, react_i18next__WEBPACK_IMPORTED_MODULE_10__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _src_components_forms_theme_elements_CustomCheckbox__WEBPACK_IMPORTED_MODULE_3__, _src_components_forms_theme_elements_CustomTextField__WEBPACK_IMPORTED_MODULE_4__, _src_components_forms_theme_elements_CustomFormLabel__WEBPACK_IMPORTED_MODULE_5__, _AuthSocialButtons__WEBPACK_IMPORTED_MODULE_6__, _src_services_Auth__WEBPACK_IMPORTED_MODULE_8__, react_hot_toast__WEBPACK_IMPORTED_MODULE_9__, react_i18next__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const AuthLogin = ({ title , subtitle , subtext  })=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_10__.useTranslation)();
    const txtSuccess = t(`Loggin Success`);
    const notifySuccess = ()=>react_hot_toast__WEBPACK_IMPORTED_MODULE_9__["default"].success(txtSuccess);
    return /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hot_toast__WEBPACK_IMPORTED_MODULE_9__.Toaster, {}),
            title ? /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                fontWeight: "700",
                variant: "h3",
                mb: 1,
                children: title
            }) : null,
            subtext,
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_AuthSocialButtons__WEBPACK_IMPORTED_MODULE_6__["default"], {
                title: "Sign in with"
            }),
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                mt: 3,
                children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Divider, {
                    children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                        component: "span",
                        color: "textSecondary",
                        variant: "h6",
                        fontWeight: "400",
                        position: "relative",
                        px: 2,
                        children: "or sign in with"
                    })
                })
            }),
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_7__.Formik, {
                initialValues: {
                    username: "",
                    password: ""
                },
                validate: (values)=>{
                    const errors = {};
                    // if (!values.email) {
                    //   errors.email = "Required";
                    // } else if (
                    //   !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(values.email)
                    // ) {
                    //   errors.email = "Invalid email address";
                    // }
                    return errors;
                },
                onSubmit: (values)=>{
                    // console.log(values, "values");
                    (0,_src_services_Auth__WEBPACK_IMPORTED_MODULE_8__/* .login */ .x)(values);
                    // const response = login(values);
                    notifySuccess();
                // window.location = "/" as any;
                // console.log(response, "response");
                // if(!response){
                //   redirect('/');
                // }
                },
                children: ({ values , errors , touched , handleChange , handleBlur , handleSubmit , isSubmitting , dirty , isValid  })=>/*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                        children: [
                            /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                                children: [
                                    /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                        children: [
                                            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_forms_theme_elements_CustomFormLabel__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                                htmlFor: "username",
                                                children: "Username"
                                            }),
                                            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_forms_theme_elements_CustomTextField__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                name: "username",
                                                onChange: handleChange,
                                                onBlur: handleBlur,
                                                type: "email",
                                                id: "username",
                                                variant: "outlined",
                                                fullWidth: true
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                        children: [
                                            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_forms_theme_elements_CustomFormLabel__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                                htmlFor: "password",
                                                children: "Password"
                                            }),
                                            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_forms_theme_elements_CustomTextField__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                id: "password",
                                                onChange: handleChange,
                                                onBlur: handleBlur,
                                                type: "password",
                                                name: "password",
                                                variant: "outlined",
                                                fullWidth: true
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                                        justifyContent: "space-between",
                                        direction: "row",
                                        alignItems: "center",
                                        my: 2,
                                        children: [
                                            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormGroup, {
                                                children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControlLabel, {
                                                    control: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_forms_theme_elements_CustomCheckbox__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                        defaultChecked: true
                                                    }),
                                                    label: "Remeber this Device"
                                                })
                                            }),
                                            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                component: (next_link__WEBPACK_IMPORTED_MODULE_2___default()),
                                                href: "/auth/forgot-password",
                                                fontWeight: "500",
                                                sx: {
                                                    textDecoration: "none",
                                                    color: "primary.main"
                                                },
                                                children: "Forgot Password ?"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                    color: "primary",
                                    variant: "contained",
                                    size: "large",
                                    fullWidth: true,
                                    onClick: ()=>handleSubmit(),
                                    children: "Sign In"
                                })
                            }),
                            subtitle
                        ]
                    })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AuthLogin);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6305:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Checkbox__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8330);
/* harmony import */ var _mui_material_Checkbox__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Checkbox__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__]);
_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const BpIcon = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.styled)("span")(({ theme  })=>({
        borderRadius: 3,
        width: 19,
        height: 19,
        marginLeft: "4px",
        boxShadow: theme.palette.mode === "dark" ? `0 0 0 1px ${theme.palette.grey[200]}` : `inset 0 0 0 1px ${theme.palette.grey[300]}`,
        backgroundColor: "transparent",
        ".Mui-focusVisible &": {
            outline: theme.palette.mode === "dark" ? `0px auto ${theme.palette.grey[200]}` : `0px auto  ${theme.palette.grey[300]}`,
            outlineOffset: 2
        },
        "input:hover ~ &": {
            backgroundColor: theme.palette.mode === "dark" ? theme.palette.primary : theme.palette.primary
        },
        "input:disabled ~ &": {
            boxShadow: "none",
            background: theme.palette.grey[100]
        }
    }));
const BpCheckedIcon = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.styled)(BpIcon)({
    boxShadow: "none",
    width: 19,
    height: 19,
    "&:before": {
        display: "block",
        width: 19,
        height: 19,
        backgroundImage: "url(\"data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3E%3Cpath" + " fill-rule='evenodd' clip-rule='evenodd' d='M12 5c-.28 0-.53.11-.71.29L7 9.59l-2.29-2.3a1.003 " + "1.003 0 00-1.42 1.42l3 3c.18.18.43.29.71.29s.53-.11.71-.29l5-5A1.003 1.003 0 0012 5z' fill='%23fff'/%3E%3C/svg%3E\")",
        content: '""'
    }
});
// Inspired by blueprintjs
function CustomCheckbox(props) {
    return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Checkbox__WEBPACK_IMPORTED_MODULE_3___default()), {
        disableRipple: true,
        color: props.color ? props.color : "default",
        checkedIcon: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(BpCheckedIcon, {
            sx: {
                backgroundColor: props.color ? `${props.color}.main` : "primary.main"
            }
        }),
        icon: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(BpIcon, {}),
        inputProps: {
            "aria-label": "Checkbox demo"
        },
        ...props
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CustomCheckbox);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5423:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "x": () => (/* binding */ login)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

// import { redirect } from 'next/navigation';
// const API = "http://localhost:3000";
const API = "https://universalsystem-clinic.onrender.com";
// import { signIn, signOut } from "next-auth/react";
const login = (values)=>{
    console.log(API, "api");
    axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${API}/usc/cosmotologist/login`, {
        email: values.username,
        password: values.password
    }).then(function(response) {
        localStorage.setItem("token", response?.data?.token);
        localStorage.setItem("id", response?.data?.id);
        // redirect('/');
        window.location = "/";
        console.log(response);
    }).catch(function(error) {
        console.log(error);
        return error;
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;