"use strict";
exports.id = 346;
exports.ids = [346];
exports.modules = {

/***/ 1346:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _src_components_forms_theme_elements_CustomTextField__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6001);
/* harmony import */ var _src_components_forms_theme_elements_CustomFormLabel__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9237);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _AuthSocialButtons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2112);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _src_components_forms_theme_elements_CustomTextField__WEBPACK_IMPORTED_MODULE_3__, _src_components_forms_theme_elements_CustomFormLabel__WEBPACK_IMPORTED_MODULE_4__, _AuthSocialButtons__WEBPACK_IMPORTED_MODULE_6__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _src_components_forms_theme_elements_CustomTextField__WEBPACK_IMPORTED_MODULE_3__, _src_components_forms_theme_elements_CustomFormLabel__WEBPACK_IMPORTED_MODULE_4__, _AuthSocialButtons__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const AuthRegister = ({ title , subtitle , subtext  })=>/*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            title ? /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                fontWeight: "700",
                variant: "h3",
                mb: 1,
                children: title
            }) : null,
            subtext,
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_AuthSocialButtons__WEBPACK_IMPORTED_MODULE_6__["default"], {
                title: "Sign up with"
            }),
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                mt: 3,
                children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Divider, {
                    children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                        component: "span",
                        color: "textSecondary",
                        variant: "h6",
                        fontWeight: "400",
                        position: "relative",
                        px: 2,
                        children: "or sign up with"
                    })
                })
            }),
            /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                children: [
                    /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_5__.Stack, {
                        mb: 3,
                        children: [
                            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_forms_theme_elements_CustomFormLabel__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                htmlFor: "name",
                                children: "Name"
                            }),
                            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_forms_theme_elements_CustomTextField__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                id: "name",
                                variant: "outlined",
                                fullWidth: true
                            }),
                            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_forms_theme_elements_CustomFormLabel__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                htmlFor: "email",
                                children: "Email Adddress"
                            }),
                            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_forms_theme_elements_CustomTextField__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                id: "email",
                                variant: "outlined",
                                fullWidth: true
                            }),
                            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_forms_theme_elements_CustomFormLabel__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                htmlFor: "password",
                                children: "Password"
                            }),
                            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_forms_theme_elements_CustomTextField__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                id: "password",
                                variant: "outlined",
                                fullWidth: true
                            })
                        ]
                    }),
                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
                        color: "primary",
                        variant: "contained",
                        size: "large",
                        fullWidth: true,
                        component: (next_link__WEBPACK_IMPORTED_MODULE_2___default()),
                        href: "/auth/auth1/login",
                        children: "Sign Up"
                    })
                ]
            }),
            subtitle
        ]
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AuthRegister);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;