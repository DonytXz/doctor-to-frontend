"use strict";
exports.id = 831;
exports.ids = [831];
exports.modules = {

/***/ 7831:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _src_components_forms_theme_elements_CustomTextField__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6001);
/* harmony import */ var _src_components_forms_theme_elements_CustomFormLabel__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9237);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _src_components_forms_theme_elements_CustomTextField__WEBPACK_IMPORTED_MODULE_3__, _src_components_forms_theme_elements_CustomFormLabel__WEBPACK_IMPORTED_MODULE_4__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _src_components_forms_theme_elements_CustomTextField__WEBPACK_IMPORTED_MODULE_3__, _src_components_forms_theme_elements_CustomFormLabel__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const AuthTwoSteps = ()=>/*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
            mt: 4,
            children: [
                /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_5__.Stack, {
                    mb: 3,
                    children: [
                        /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_src_components_forms_theme_elements_CustomFormLabel__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                            htmlFor: "code",
                            children: [
                                "Type your 6 digits security code",
                                " "
                            ]
                        }),
                        /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_5__.Stack, {
                            spacing: 2,
                            direction: "row",
                            children: [
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_forms_theme_elements_CustomTextField__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    id: "code",
                                    variant: "outlined",
                                    fullWidth: true
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_forms_theme_elements_CustomTextField__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    id: "code",
                                    variant: "outlined",
                                    fullWidth: true
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_forms_theme_elements_CustomTextField__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    id: "code",
                                    variant: "outlined",
                                    fullWidth: true
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_forms_theme_elements_CustomTextField__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    id: "code",
                                    variant: "outlined",
                                    fullWidth: true
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_forms_theme_elements_CustomTextField__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    id: "code",
                                    variant: "outlined",
                                    fullWidth: true
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_forms_theme_elements_CustomTextField__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    id: "code",
                                    variant: "outlined",
                                    fullWidth: true
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
                    color: "primary",
                    variant: "contained",
                    size: "large",
                    fullWidth: true,
                    component: (next_link__WEBPACK_IMPORTED_MODULE_2___default()),
                    href: "/",
                    children: "Verify My Account"
                }),
                /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_5__.Stack, {
                    direction: "row",
                    spacing: 1,
                    mt: 3,
                    children: [
                        /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                            color: "textSecondary",
                            variant: "h6",
                            fontWeight: "400",
                            children: "Didn't get the code?"
                        }),
                        /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                            component: (next_link__WEBPACK_IMPORTED_MODULE_2___default()),
                            href: "/",
                            fontWeight: "500",
                            sx: {
                                textDecoration: "none",
                                color: "primary.main"
                            },
                            children: "Resend"
                        })
                    ]
                })
            ]
        })
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AuthTwoSteps);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;