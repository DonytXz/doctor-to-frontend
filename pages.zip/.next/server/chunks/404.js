"use strict";
exports.id = 404;
exports.ids = [404];
exports.modules = {

/***/ 7404:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I0": () => (/* binding */ useDispatch),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "v9": () => (/* binding */ useSelector)
/* harmony export */ });
/* unused harmony exports store, dispatch */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9065);
/* harmony import */ var _apps_eCommerce_ECommerceSlice__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5615);
/* harmony import */ var _apps_chat_ChatSlice__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5899);
/* harmony import */ var _apps_notes_NotesSlice__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9060);
/* harmony import */ var _apps_email_EmailSlice__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5058);
/* harmony import */ var _apps_tickets_TicketSlice__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(114);
/* harmony import */ var _apps_contacts_ContactSlice__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2696);
/* harmony import */ var _apps_userProfile_UserProfileSlice__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1398);
/* harmony import */ var _apps_blog_BlogSlice__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5093);
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6695);
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(redux__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_11__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_apps_eCommerce_ECommerceSlice__WEBPACK_IMPORTED_MODULE_2__, _apps_chat_ChatSlice__WEBPACK_IMPORTED_MODULE_3__, _apps_notes_NotesSlice__WEBPACK_IMPORTED_MODULE_4__, _apps_email_EmailSlice__WEBPACK_IMPORTED_MODULE_5__, _apps_tickets_TicketSlice__WEBPACK_IMPORTED_MODULE_6__, _apps_contacts_ContactSlice__WEBPACK_IMPORTED_MODULE_7__, _apps_userProfile_UserProfileSlice__WEBPACK_IMPORTED_MODULE_8__, _apps_blog_BlogSlice__WEBPACK_IMPORTED_MODULE_9__]);
([_apps_eCommerce_ECommerceSlice__WEBPACK_IMPORTED_MODULE_2__, _apps_chat_ChatSlice__WEBPACK_IMPORTED_MODULE_3__, _apps_notes_NotesSlice__WEBPACK_IMPORTED_MODULE_4__, _apps_email_EmailSlice__WEBPACK_IMPORTED_MODULE_5__, _apps_tickets_TicketSlice__WEBPACK_IMPORTED_MODULE_6__, _apps_contacts_ContactSlice__WEBPACK_IMPORTED_MODULE_7__, _apps_userProfile_UserProfileSlice__WEBPACK_IMPORTED_MODULE_8__, _apps_blog_BlogSlice__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const store = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.configureStore)({
    reducer: {
        customizer: _customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP,
        ecommerceReducer: _apps_eCommerce_ECommerceSlice__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP,
        chatReducer: _apps_chat_ChatSlice__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP,
        emailReducer: _apps_email_EmailSlice__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP,
        notesReducer: _apps_notes_NotesSlice__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP,
        contactsReducer: _apps_contacts_ContactSlice__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP,
        ticketReducer: _apps_tickets_TicketSlice__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP,
        userpostsReducer: _apps_userProfile_UserProfileSlice__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .ZP,
        blogReducer: _apps_blog_BlogSlice__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .ZP
    }
});
const rootReducer = (0,redux__WEBPACK_IMPORTED_MODULE_10__.combineReducers)({
    customizer: _customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP,
    ecommerceReducer: _apps_eCommerce_ECommerceSlice__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP,
    chatReducer: _apps_chat_ChatSlice__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP,
    emailReducer: _apps_email_EmailSlice__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP,
    notesReducer: _apps_notes_NotesSlice__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP,
    contactsReducer: _apps_contacts_ContactSlice__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP,
    ticketReducer: _apps_tickets_TicketSlice__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP,
    userpostsReducer: _apps_userProfile_UserProfileSlice__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .ZP,
    blogReducer: _apps_blog_BlogSlice__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .ZP
});
const { dispatch  } = store;
const useDispatch = ()=>(0,react_redux__WEBPACK_IMPORTED_MODULE_11__.useDispatch)();
const useSelector = react_redux__WEBPACK_IMPORTED_MODULE_11__.useSelector;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (store);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5093:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports BlogSlice, getPosts, getPost, fetchBlogPosts, addComment, fetchBlogPost */
/* harmony import */ var _utils_axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5584);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_axios__WEBPACK_IMPORTED_MODULE_0__]);
_utils_axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const initialState = {
    blogposts: [],
    recentPosts: [],
    blogSearch: "",
    sortBy: "newest",
    selectedPost: null
};
const BlogSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__.createSlice)({
    name: "Blog",
    initialState,
    reducers: {
        getPosts: (state, action)=>{
            state.blogposts = action.payload;
        },
        getPost: (state, action)=>{
            state.selectedPost = action.payload;
        }
    }
});
const { getPosts , getPost  } = BlogSlice.actions;
const fetchBlogPosts = ()=>async (dispatch)=>{
        try {
            const response = await axios.get("/api/data/blog/BlogPosts");
            dispatch(getPosts(response.data));
        } catch (err) {
            throw new Error();
        }
    };
const addComment = (postId, comment)=>async (dispatch)=>{
        try {
            const response = await axios.post("/api/data/blog/post/add", {
                postId,
                comment
            });
            dispatch(getPosts(response.data.posts));
        } catch (err) {
            throw new Error(err);
        }
    };
const fetchBlogPost = (title)=>async (dispatch)=>{
        try {
            const response = await axios.post("/api/data/blog/post", {
                title
            });
            dispatch(getPosts(response.data.post));
        } catch (err) {
            console.log(err);
            throw new Error(err);
        }
    };
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BlogSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5899:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports ChatSlice, SearchChat, getChats, sendMsg, SelectChat, fetchChats */
/* harmony import */ var _utils_axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5584);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6517);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4146);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_axios__WEBPACK_IMPORTED_MODULE_0__]);
_utils_axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const API_URL = "/api/data/chat/ChatData";
const initialState = {
    chats: [],
    chatContent: 1,
    chatSearch: ""
};
const ChatSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__.createSlice)({
    name: "chat",
    initialState,
    reducers: {
        getChats: (state, action)=>{
            state.chats = action.payload;
        },
        SearchChat: (state, action)=>{
            state.chatSearch = action.payload;
        },
        SelectChat: (state, action)=>{
            state.chatContent = action.payload;
        },
        sendMsg: (state, action)=>{
            const conversation = action.payload;
            const { id , msg  } = conversation;
            const newMessage = {
                id: id,
                msg: msg,
                type: "text",
                attachments: [],
                createdAt: (0,date_fns__WEBPACK_IMPORTED_MODULE_3__.sub)(new Date(), {
                    seconds: 1
                }),
                senderId: (0,lodash__WEBPACK_IMPORTED_MODULE_2__.uniqueId)()
            };
            state.chats = state.chats.map((chat)=>chat.id === action.payload.id ? {
                    ...chat,
                    ...chat.messages.push(newMessage)
                } : chat);
        }
    }
});
const { SearchChat , getChats , sendMsg , SelectChat  } = ChatSlice.actions;
const fetchChats = ()=>async (dispatch)=>{
        try {
            const response = await axios.get(`${API_URL}`);
            dispatch(getChats(response.data));
        } catch (err) {
            throw new Error(err);
        }
    };
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ChatSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2696:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports ContactSlice, getContacts, SearchContact, isEdit, SelectContact, DeleteContact, toggleStarredContact, UpdateContact, addContact, setVisibilityFilter, fetchContacts */
/* harmony import */ var _utils_axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5584);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_axios__WEBPACK_IMPORTED_MODULE_0__]);
_utils_axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const API_URL = "/api/data/contacts/ContactsData";
const initialState = {
    contacts: [],
    contactContent: 1,
    contactSearch: "",
    editContact: false,
    currentFilter: "show_all"
};
const ContactSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__.createSlice)({
    name: "contacts",
    initialState,
    reducers: {
        getContacts: (state, action)=>{
            state.contacts = action.payload;
        },
        SearchContact: (state, action)=>{
            state.contactSearch = action.payload;
        },
        SelectContact: (state, action)=>{
            state.contactContent = action.payload;
        },
        DeleteContact: (state, action)=>{
            state.contacts = state.contacts.map((contact)=>contact.id === action.payload ? {
                    ...contact,
                    deleted: !contact.deleted
                } : contact);
        },
        toggleStarredContact: (state, action)=>{
            state.contacts = state.contacts.map((contact)=>contact.id === action.payload ? {
                    ...contact,
                    starred: !contact.starred
                } : contact);
        },
        isEdit: (state)=>{
            state.editContact = !state.editContact;
        },
        setVisibilityFilter: (state, action)=>{
            state.currentFilter = action.payload;
        },
        UpdateContact: {
            reducer: (state, action)=>{
                state.contacts = state.contacts.map((contact)=>contact.id === action.payload.id ? {
                        ...contact,
                        [action.payload.field]: action.payload.value
                    } : contact);
            },
            prepare: (id, field, value)=>{
                return {
                    payload: {
                        id,
                        field,
                        value
                    }
                };
            }
        },
        addContact: {
            reducer: (state, action)=>{
                state.contacts.push(action.payload);
            },
            prepare: (id, firstname, lastname, image, department, company, phone, email, address, notes)=>{
                return {
                    payload: {
                        id,
                        firstname,
                        lastname,
                        image,
                        department,
                        company,
                        phone,
                        email,
                        address,
                        notes,
                        frequentlycontacted: false,
                        starred: false,
                        deleted: false
                    }
                };
            }
        }
    }
});
const { getContacts , SearchContact , isEdit , SelectContact , DeleteContact , toggleStarredContact , UpdateContact , addContact , setVisibilityFilter  } = ContactSlice.actions;
const fetchContacts = ()=>async (dispatch)=>{
        try {
            const response = await axios.get(`${API_URL}`);
            dispatch(getContacts(response.data));
        } catch (err) {
            throw new Error(err);
        }
    };
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ContactSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5615:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Mj": () => (/* binding */ decrement),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "nP": () => (/* binding */ increment)
/* harmony export */ });
/* unused harmony exports EcommerceSlice, hasError, getProducts, SearchProduct, sortByProducts, filterProducts, sortByGender, deleteCart, addToCart, sortByPrice, filterReset, sortByColor, fetchProducts */
/* harmony import */ var _utils_axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5584);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6517);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_axios__WEBPACK_IMPORTED_MODULE_0__]);
_utils_axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const API_URL = "/api/data/eCommerce/ProductsData";
const initialState = {
    products: [],
    productSearch: "",
    sortBy: "newest",
    cart: [],
    total: 0,
    filters: {
        category: "All",
        color: "All",
        gender: "All",
        price: "All",
        rating: ""
    },
    error: ""
};
const EcommerceSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_2__.createSlice)({
    name: "ecommerce",
    initialState,
    reducers: {
        // HAS ERROR
        hasError (state, action) {
            state.error = action.payload;
        },
        // GET PRODUCTS
        getProducts: (state, action)=>{
            state.products = action.payload;
        },
        SearchProduct: (state, action)=>{
            state.productSearch = action.payload;
        },
        //  SORT  PRODUCTS
        sortByProducts (state, action) {
            state.sortBy = action.payload;
        },
        //  SORT  PRODUCTS
        sortByGender (state, action) {
            state.filters.gender = action.payload.gender;
        },
        //  SORT  By Color
        sortByColor (state, action) {
            state.filters.color = action.payload.color;
        },
        //  SORT  By Color
        sortByPrice (state, action) {
            state.filters.price = action.payload.price;
        },
        //  FILTER PRODUCTS
        filterProducts (state, action) {
            state.filters.category = action.payload.category;
        },
        //  FILTER Reset
        filterReset (state) {
            state.filters.category = "All";
            state.filters.color = "All";
            state.filters.gender = "All";
            state.filters.price = "All";
            state.sortBy = "newest";
        },
        // ADD TO CART
        addToCart (state, action) {
            const product = action.payload;
            state.cart = [
                ...state.cart,
                product
            ];
        },
        // qty increment
        increment (state, action) {
            const productId = action.payload;
            const updateCart = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.map)(state.cart, (product)=>{
                if (product.id === productId) {
                    return {
                        ...product,
                        qty: product.qty + 1
                    };
                }
                return product;
            });
            state.cart = updateCart;
        },
        // qty decrement
        decrement (state, action) {
            const productId = action.payload;
            const updateCart = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.map)(state.cart, (product)=>{
                if (product.id === productId) {
                    return {
                        ...product,
                        qty: product.qty - 1
                    };
                }
                return product;
            });
            state.cart = updateCart;
        },
        // delete Cart
        deleteCart (state, action) {
            const updateCart = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.filter)(state.cart, (item)=>item.id !== action.payload);
            state.cart = updateCart;
        }
    }
});
const { hasError , getProducts , SearchProduct , sortByProducts , filterProducts , sortByGender , increment , deleteCart , decrement , addToCart , sortByPrice , filterReset , sortByColor  } = EcommerceSlice.actions;
const fetchProducts = ()=>async (dispatch)=>{
        try {
            const response = await axios.get(`${API_URL}`);
            dispatch(getProducts(response.data));
        } catch (error) {
            dispatch(hasError(error));
        }
    };
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EcommerceSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5058:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports EmailSlice, SearchEmail, SelectEmail, getEmails, starEmail, importantEmail, setVisibilityFilter, deleteEmail, checkEmail, fetchEmails */
/* harmony import */ var _utils_axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5584);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_axios__WEBPACK_IMPORTED_MODULE_0__]);
_utils_axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const API_URL = "/api/data/email/EmailData";
const initialState = {
    emails: [],
    emailContent: 1,
    emailSearch: "",
    currentFilter: "inbox"
};
const EmailSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__.createSlice)({
    name: "email",
    initialState,
    reducers: {
        getEmails: (state, action)=>{
            state.emails = action.payload;
        },
        SearchEmail: (state, action)=>{
            state.emailSearch = action.payload;
        },
        SelectEmail: (state, action)=>{
            state.emailContent = action.payload;
        },
        starEmail: (state, action)=>{
            state.emails = state.emails.map((email)=>email.id === action.payload ? {
                    ...email,
                    starred: !email.starred
                } : email);
        },
        importantEmail: (state, action)=>{
            state.emails = state.emails.map((email)=>email.id === action.payload ? {
                    ...email,
                    important: !email.important
                } : email);
        },
        checkEmail: (state, action)=>{
            state.emails = state.emails.map((email)=>email.id === action.payload ? {
                    ...email,
                    checked: !email.checked
                } : email);
        },
        deleteEmail: (state, action)=>{
            state.emails = state.emails.map((email)=>email.id === action.payload ? {
                    ...email,
                    trash: !email.trash
                } : email);
        },
        setVisibilityFilter: (state, action)=>{
            state.currentFilter = action.payload;
        }
    }
});
const { SearchEmail , SelectEmail , getEmails , starEmail , importantEmail , setVisibilityFilter , deleteEmail , checkEmail  } = EmailSlice.actions;
const fetchEmails = ()=>async (dispatch)=>{
        try {
            const response = await axios.get(`${API_URL}`);
            dispatch(getEmails(response.data));
        } catch (err) {
            throw new Error(err);
        }
    };
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EmailSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9060:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports NotesSlice, SearchNotes, getNotes, SelectNote, DeleteNote, UpdateNote, addNote, fetchNotes */
/* harmony import */ var _utils_axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5584);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_axios__WEBPACK_IMPORTED_MODULE_0__]);
_utils_axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const API_URL = "/api/data/notes/NotesData";
const initialState = {
    notes: [],
    notesContent: 1,
    noteSearch: ""
};
const NotesSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__.createSlice)({
    name: "notes",
    initialState,
    reducers: {
        getNotes: (state, action)=>{
            state.notes = action.payload;
        },
        SearchNotes: (state, action)=>{
            state.noteSearch = action.payload;
        },
        SelectNote: (state, action)=>{
            state.notesContent = action.payload;
        },
        DeleteNote (state, action) {
            const index = state.notes.findIndex((note)=>note.id === action.payload);
            state.notes.splice(index, 1);
        },
        UpdateNote: {
            reducer: (state, action)=>{
                state.notes = state.notes.map((note)=>note.id === action.payload.id ? {
                        ...note,
                        [action.payload.field]: action.payload.value
                    } : note);
            },
            prepare: (id, field, value)=>{
                return {
                    payload: {
                        id,
                        field,
                        value
                    }
                };
            }
        },
        addNote: {
            reducer: (state, action)=>{
                state.notes.push(action.payload);
            },
            prepare: (id, title, color)=>{
                return {
                    payload: {
                        id,
                        title,
                        color,
                        datef: new Date().toDateString(),
                        deleted: false
                    }
                };
            }
        }
    }
});
const { SearchNotes , getNotes , SelectNote , DeleteNote , UpdateNote , addNote  } = NotesSlice.actions;
const fetchNotes = ()=>async (dispatch)=>{
        try {
            const response = await axios.get(`${API_URL}`);
            dispatch(getNotes(response.data));
        } catch (err) {
            throw new Error(err);
        }
    };
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NotesSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 114:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports TicketSlice, getTickets, setVisibilityFilter, SearchTicket, DeleteTicket, fetchTickets */
/* harmony import */ var _utils_axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5584);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_axios__WEBPACK_IMPORTED_MODULE_0__]);
_utils_axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const API_URL = "/api/data/ticket/TicketData";
const initialState = {
    tickets: [],
    currentFilter: "total_tickets",
    ticketSearch: ""
};
const TicketSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__.createSlice)({
    name: "ticket",
    initialState,
    reducers: {
        getTickets: (state, action)=>{
            state.tickets = action.payload;
        },
        setVisibilityFilter: (state, action)=>{
            state.currentFilter = action.payload;
        },
        SearchTicket: (state, action)=>{
            state.ticketSearch = action.payload;
        },
        DeleteTicket: (state, action)=>{
            const index = state.tickets.findIndex((ticket)=>ticket.Id === action.payload);
            state.tickets.splice(index, 1);
        }
    }
});
const { getTickets , setVisibilityFilter , SearchTicket , DeleteTicket  } = TicketSlice.actions;
const fetchTickets = ()=>async (dispatch)=>{
        try {
            const response = await axios.get(`${API_URL}`);
            dispatch(getTickets(response.data));
        } catch (err) {
            throw new Error(err);
        }
    };
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TicketSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1398:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports UserProfileSlice, getPosts, getFollowers, onToggleFollow, getPhotos, fetchPosts, likePosts, addComment, addReply, fetchFollwores, fetchPhotos */
/* harmony import */ var _utils_axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5584);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6517);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_axios__WEBPACK_IMPORTED_MODULE_0__]);
_utils_axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const API_URL = "/api/data/postData";
const initialState = {
    posts: [],
    followers: [],
    gallery: []
};
const UserProfileSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__.createSlice)({
    name: "UserPost",
    initialState,
    reducers: {
        getPosts: (state, action)=>{
            state.posts = action.payload;
        },
        getFollowers: (state, action)=>{
            state.followers = action.payload;
        },
        getPhotos: (state, action)=>{
            state.gallery = action.payload;
        },
        onToggleFollow (state, action) {
            const followerId = action.payload;
            const handleToggle = (0,lodash__WEBPACK_IMPORTED_MODULE_2__.map)(state.followers, (follower)=>{
                if (follower.id === followerId) {
                    return {
                        ...follower,
                        isFollowed: !follower.isFollowed
                    };
                }
                return follower;
            });
            state.followers = handleToggle;
        }
    }
});
const { getPosts , getFollowers , onToggleFollow , getPhotos  } = UserProfileSlice.actions;
const fetchPosts = ()=>async (dispatch)=>{
        try {
            const response = await axios.get(`${API_URL}`);
            dispatch(getPosts(response.data));
        } catch (err) {
            throw new Error(err);
        }
    };
const likePosts = (postId)=>async (dispatch)=>{
        try {
            const response = await axios.post("/api/data/posts/like", {
                postId
            });
            dispatch(getPosts(response.data.posts));
        } catch (err) {
            throw new Error(err);
        }
    };
const addComment = (postId, comment)=>async (dispatch)=>{
        try {
            const response = await axios.post("/api/data/posts/comments/add", {
                postId,
                comment
            });
            dispatch(getPosts(response.data.posts));
        } catch (err) {
            throw new Error(err);
        }
    };
const addReply = (postId, commentId, reply)=>async (dispatch)=>{
        try {
            const response = await axios.post("/api/data/posts/replies/add", {
                postId,
                commentId,
                reply
            });
            dispatch(getPosts(response.data.posts));
        } catch (err) {
            throw new Error(err);
        }
    };
const fetchFollwores = ()=>async (dispatch)=>{
        try {
            const response = await axios.get(`/api/data/users`);
            dispatch(getFollowers(response.data));
        } catch (err) {
            throw new Error(err);
        }
    };
const fetchPhotos = ()=>async (dispatch)=>{
        try {
            const response = await axios.get(`/api/data/gallery`);
            dispatch(getPhotos(response.data));
        } catch (err) {
            throw new Error(err);
        }
    };
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UserProfileSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9065:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C8": () => (/* binding */ setDarkMode),
/* harmony export */   "Dc": () => (/* binding */ setTheme),
/* harmony export */   "GB": () => (/* binding */ toggleSidebar),
/* harmony export */   "Jh": () => (/* binding */ setBorderRadius),
/* harmony export */   "Sz": () => (/* binding */ toggleHorizontal),
/* harmony export */   "VE": () => (/* binding */ toggleLayout),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "bR": () => (/* binding */ hoverSidebar),
/* harmony export */   "lv": () => (/* binding */ setDir),
/* harmony export */   "m0": () => (/* binding */ setLanguage),
/* harmony export */   "tW": () => (/* binding */ toggleMobileSidebar),
/* harmony export */   "xu": () => (/* binding */ setCardShadow)
/* harmony export */ });
/* unused harmony export CustomizerSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    activeDir: "ltr",
    activeMode: "light",
    activeTheme: "BLUE_THEME",
    SidebarWidth: 270,
    MiniSidebarWidth: 87,
    TopbarHeight: 70,
    isLayout: "boxed",
    isCollapse: false,
    isSidebarHover: false,
    isMobileSidebar: false,
    isHorizontal: false,
    isLanguage: "es",
    isCardShadow: true,
    borderRadius: 7
};
const CustomizerSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "customizer",
    initialState,
    reducers: {
        setTheme: (state, action)=>{
            state.activeTheme = action.payload;
        },
        setDarkMode: (state, action)=>{
            state.activeMode = action.payload;
        },
        setDir: (state, action)=>{
            state.activeDir = action.payload;
        },
        setLanguage: (state, action)=>{
            console.log(state.isLanguage);
            console.log(action.payload, "\xe4sdsa");
            state.isLanguage = action.payload;
        },
        setCardShadow: (state, action)=>{
            state.isCardShadow = action.payload;
        },
        toggleSidebar: (state)=>{
            state.isCollapse = !state.isCollapse;
        },
        hoverSidebar: (state, action)=>{
            state.isSidebarHover = action.payload;
        },
        toggleMobileSidebar: (state)=>{
            state.isMobileSidebar = !state.isMobileSidebar;
        },
        toggleLayout: (state, action)=>{
            state.isLayout = action.payload;
        },
        toggleHorizontal: (state, action)=>{
            state.isHorizontal = action.payload;
        },
        setBorderRadius: (state, action)=>{
            state.borderRadius = action.payload;
        }
    }
});
const { setTheme , setDarkMode , setDir , toggleSidebar , hoverSidebar , toggleMobileSidebar , toggleLayout , setBorderRadius , toggleHorizontal , setLanguage , setCardShadow  } = CustomizerSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CustomizerSlice.reducer);


/***/ }),

/***/ 5584:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const axiosServices = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create();
// interceptor for http
axiosServices.interceptors.response.use((response)=>response, (error)=>Promise.reject(error.response && error.response.data || "Wrong Services"));
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (axiosServices);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;