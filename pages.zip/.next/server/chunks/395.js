"use strict";
exports.id = 395;
exports.ids = [395];
exports.modules = {

/***/ 8351:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "K": () => (/* binding */ storePatient),
/* harmony export */   "X": () => (/* binding */ getPatients)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

// const API = "http://localhost:3000";
const API = "https://universalsystem-clinic.onrender.com";
const storePatient = (patient)=>{
    let id;
    let token;
    if (false) {}
    const config = {
        headers: {
            meID: id,
            "auth-token": token
        }
    };
    axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${API}/usc/patient/create`, patient, config).then(function(response) {
        console.log(response);
        window.location = "/patients/list";
    }).catch(function(error) {
        console.log(error);
    });
};
// export async function getPatients() {
//   try {
//     const response = await axios.get(`${API}/usc/patient/retrieve`);
//     console.log(response, "response");
//     return response.data;
//   } catch (error) {
//     console.error(error);
//   }
// }
const getPatients = async ()=>{
    let id;
    let token;
    if (false) {}
    const config = {
        headers: {
            meID: id,
            "auth-token": token
        }
    };
    console.log(API, "api");
    try {
        const response = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].get(`${API}/usc/patient/retrieve`, config);
        return response.data;
    // console.log(response);
    } catch (error) {
    // console.error(error);
    }
// axios
//   .get(`${API}/usc/patient/retrieve`)
//   .then(function (response) {
//     console.log(response, "response");
//     return response.data.result;
//   })
//   .catch(function (error) {
//     console.log(error);
//     return error;
//   });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 614:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "O": () => (/* binding */ BCrumPatients)
/* harmony export */ });
const BCrumPatients = [
    {
        to: "/patients/list",
        title: "Patients List"
    },
    {
        to: "/patients/register",
        title: "Patient Register"
    }
];


/***/ })

};
;