(() => {
var exports = {};
exports.id = 888;
exports.ids = [888,3,126,139,15];
exports.modules = {

/***/ 5774:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/empty-shopping-cart.8b30a40c.svg","height":1080,"width":1080});

/***/ }),

/***/ 3847:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4960);
/* harmony import */ var _mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3139);
/* harmony import */ var _src_theme_Theme__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9260);
/* harmony import */ var _src_createEmotionCache__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8172);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _src_store_Store__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7404);
/* harmony import */ var _src_layouts_full_shared_customizer_RTL__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3630);
/* harmony import */ var _src_layouts_blank_BlankLayout__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8925);
/* harmony import */ var _src_layouts_full_FullLayout__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5215);
/* harmony import */ var _src_mockApis__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9637);
/* harmony import */ var _src_utils_i18n__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6934);
/* harmony import */ var react_quill_dist_quill_snow_css__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1791);
/* harmony import */ var react_quill_dist_quill_snow_css__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(react_quill_dist_quill_snow_css__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(8278);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(782);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _global_css__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(245);
/* harmony import */ var _global_css__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(_global_css__WEBPACK_IMPORTED_MODULE_18__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _emotion_react__WEBPACK_IMPORTED_MODULE_5__, _src_theme_Theme__WEBPACK_IMPORTED_MODULE_6__, _src_store_Store__WEBPACK_IMPORTED_MODULE_9__, _src_layouts_full_shared_customizer_RTL__WEBPACK_IMPORTED_MODULE_10__, _src_layouts_blank_BlankLayout__WEBPACK_IMPORTED_MODULE_11__, _src_layouts_full_FullLayout__WEBPACK_IMPORTED_MODULE_12__, _src_mockApis__WEBPACK_IMPORTED_MODULE_13__, _src_utils_i18n__WEBPACK_IMPORTED_MODULE_14__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _emotion_react__WEBPACK_IMPORTED_MODULE_5__, _src_theme_Theme__WEBPACK_IMPORTED_MODULE_6__, _src_store_Store__WEBPACK_IMPORTED_MODULE_9__, _src_layouts_full_shared_customizer_RTL__WEBPACK_IMPORTED_MODULE_10__, _src_layouts_blank_BlankLayout__WEBPACK_IMPORTED_MODULE_11__, _src_layouts_full_FullLayout__WEBPACK_IMPORTED_MODULE_12__, _src_mockApis__WEBPACK_IMPORTED_MODULE_13__, _src_utils_i18n__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
















// CSS FILES




// Client-side cache, shared for the whole session of the user in the browser.
const clientSideEmotionCache = (0,_src_createEmotionCache__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
const layouts = {
    Blank: _src_layouts_blank_BlankLayout__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z
};
const MyApp = (props)=>{
    const { Component , emotionCache =clientSideEmotionCache , pageProps  } = props;
    const theme = (0,_src_theme_Theme__WEBPACK_IMPORTED_MODULE_6__/* .ThemeSettings */ .f)();
    const customizer = (0,_src_store_Store__WEBPACK_IMPORTED_MODULE_9__/* .useSelector */ .v9)((state)=>state.customizer);
    const layout = pageProps.layout || "Full";
    const Layout = layouts[Component.layout] || _src_layouts_full_FullLayout__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z;
    return /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_emotion_react__WEBPACK_IMPORTED_MODULE_5__.CacheProvider, {
        value: emotionCache,
        children: [
            /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
                children: [
                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: "Cosmetic Services | ERP"
                    }),
                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: "Cosmetic Services.."
                    }, "desc"),
                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "viewport",
                        content: "initial-scale=1, width=device-width"
                    })
                ]
            }),
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material_styles__WEBPACK_IMPORTED_MODULE_3__.ThemeProvider, {
                theme: theme,
                children: /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_src_layouts_full_shared_customizer_RTL__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                    direction: customizer.activeDir,
                    children: [
                        /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_4___default()), {}),
                        /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Layout, {
                            children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                                ...pageProps
                            })
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>/*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_redux__WEBPACK_IMPORTED_MODULE_8__.Provider, {
        store: _src_store_Store__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .ZP,
        children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MyApp, {
            ...props
        })
    }));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9637:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var _mock__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1472);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_mock__WEBPACK_IMPORTED_MODULE_0__]);
_mock__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

_mock__WEBPACK_IMPORTED_MODULE_0__/* ["default"].onAny */ .Z.onAny().passThrough();

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1472:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios_mock_adapter__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6963);
/* harmony import */ var axios_mock_adapter__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios_mock_adapter__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5584);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_axios__WEBPACK_IMPORTED_MODULE_1__]);
_utils_axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const mock = new (axios_mock_adapter__WEBPACK_IMPORTED_MODULE_0___default())(_utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
    delayResponse: 0
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (mock);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5917:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var simplebar_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4172);
/* harmony import */ var simplebar_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(simplebar_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var simplebar_react_dist_simplebar_min_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8710);
/* harmony import */ var simplebar_react_dist_simplebar_min_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(simplebar_react_dist_simplebar_min_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__]);
_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const SimpleBarStyle = (0,_mui_material__WEBPACK_IMPORTED_MODULE_3__.styled)((simplebar_react__WEBPACK_IMPORTED_MODULE_1___default()))(()=>({
        maxHeight: "100%"
    }));
const Scrollbar = (props)=>{
    const { children , sx , ...other } = props;
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    if (isMobile) {
        return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
            sx: {
                overflowX: "auto"
            },
            children: children
        });
    }
    return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SimpleBarStyle, {
        sx: sx,
        ...other,
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Scrollbar);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8172:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ createEmotionCache)
/* harmony export */ });
/* harmony import */ var _emotion_cache__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1913);
/* harmony import */ var _emotion_cache__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_emotion_cache__WEBPACK_IMPORTED_MODULE_0__);

const isBrowser = typeof document !== "undefined";
// On the client side, Create a meta tag at the top of the <head> and set it as insertionPoint.
// This assures that MUI styles are loaded first.
// It allows developers to easily override MUI styles with other styling solutions, like CSS modules.
function createEmotionCache() {
    let insertionPoint;
    if (isBrowser) {
        const emotionInsertionPoint = document.querySelector('meta[name="emotion-insertion-point"]');
        insertionPoint = emotionInsertionPoint ?? undefined;
    }
    return _emotion_cache__WEBPACK_IMPORTED_MODULE_0___default()({
        key: "mui-style",
        insertionPoint
    });
}


/***/ }),

/***/ 8925:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__]);
_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const BlankLayout = ({ children  })=>{
    return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BlankLayout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5215:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _store_Store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7404);
/* harmony import */ var _vertical_header_Header__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8677);
/* harmony import */ var _vertical_sidebar_Sidebar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5294);
/* harmony import */ var _shared_customizer_Customizer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7548);
/* harmony import */ var _full_horizontal_navbar_Navigation__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6030);
/* harmony import */ var _full_horizontal_header_Header__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9480);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _store_Store__WEBPACK_IMPORTED_MODULE_2__, _vertical_header_Header__WEBPACK_IMPORTED_MODULE_3__, _vertical_sidebar_Sidebar__WEBPACK_IMPORTED_MODULE_4__, _shared_customizer_Customizer__WEBPACK_IMPORTED_MODULE_5__, _full_horizontal_navbar_Navigation__WEBPACK_IMPORTED_MODULE_6__, _full_horizontal_header_Header__WEBPACK_IMPORTED_MODULE_7__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _store_Store__WEBPACK_IMPORTED_MODULE_2__, _vertical_header_Header__WEBPACK_IMPORTED_MODULE_3__, _vertical_sidebar_Sidebar__WEBPACK_IMPORTED_MODULE_4__, _shared_customizer_Customizer__WEBPACK_IMPORTED_MODULE_5__, _full_horizontal_navbar_Navigation__WEBPACK_IMPORTED_MODULE_6__, _full_horizontal_header_Header__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const MainWrapper = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.styled)("div")(()=>({
        display: "flex",
        minHeight: "100vh",
        width: "100%"
    }));
const PageWrapper = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.styled)("div")(()=>({
        display: "flex",
        flexGrow: 1,
        paddingBottom: "60px",
        flexDirection: "column",
        zIndex: 1,
        width: "100%",
        backgroundColor: "transparent"
    }));
// const FullLayout: FC = ({children}) => {
const FullLayout = ({ children  })=>{
    const customizer = (0,_store_Store__WEBPACK_IMPORTED_MODULE_2__/* .useSelector */ .v9)((state)=>state.customizer);
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
    return /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(MainWrapper, {
        children: [
            customizer.isHorizontal ? "" : /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_vertical_sidebar_Sidebar__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(PageWrapper, {
                className: "page-wrapper",
                sx: {
                    ...customizer.isCollapse && {
                        [theme.breakpoints.up("lg")]: {
                            ml: `${customizer.MiniSidebarWidth}px`
                        }
                    }
                },
                children: [
                    customizer.isHorizontal ? /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_full_horizontal_header_Header__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}) : /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_vertical_header_Header__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
                    customizer.isHorizontal ? /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_full_horizontal_navbar_Navigation__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}) : "",
                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Container, {
                        sx: {
                            maxWidth: customizer.isLayout === "boxed" ? "lg" : "100%!important"
                        },
                        children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                            sx: {
                                minHeight: "calc(100vh - 170px)"
                            },
                            children: children
                        })
                    }),
                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_shared_customizer_Customizer__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FullLayout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9480:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _store_Store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7404);
/* harmony import */ var _store_customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9065);
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2236);
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _layouts_full_vertical_header_Notification__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5893);
/* harmony import */ var _layouts_full_vertical_header_Cart__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1816);
/* harmony import */ var _layouts_full_vertical_header_Profile__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8012);
/* harmony import */ var _layouts_full_vertical_header_Search__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8805);
/* harmony import */ var _layouts_full_vertical_header_Language__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4383);
/* harmony import */ var _layouts_full_vertical_header_Navigation__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4838);
/* harmony import */ var _layouts_full_shared_logo_Logo__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2095);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _store_Store__WEBPACK_IMPORTED_MODULE_3__, _layouts_full_vertical_header_Notification__WEBPACK_IMPORTED_MODULE_6__, _layouts_full_vertical_header_Cart__WEBPACK_IMPORTED_MODULE_7__, _layouts_full_vertical_header_Profile__WEBPACK_IMPORTED_MODULE_8__, _layouts_full_vertical_header_Search__WEBPACK_IMPORTED_MODULE_9__, _layouts_full_vertical_header_Language__WEBPACK_IMPORTED_MODULE_10__, _layouts_full_vertical_header_Navigation__WEBPACK_IMPORTED_MODULE_11__, _layouts_full_shared_logo_Logo__WEBPACK_IMPORTED_MODULE_12__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _store_Store__WEBPACK_IMPORTED_MODULE_3__, _layouts_full_vertical_header_Notification__WEBPACK_IMPORTED_MODULE_6__, _layouts_full_vertical_header_Cart__WEBPACK_IMPORTED_MODULE_7__, _layouts_full_vertical_header_Profile__WEBPACK_IMPORTED_MODULE_8__, _layouts_full_vertical_header_Search__WEBPACK_IMPORTED_MODULE_9__, _layouts_full_vertical_header_Language__WEBPACK_IMPORTED_MODULE_10__, _layouts_full_vertical_header_Navigation__WEBPACK_IMPORTED_MODULE_11__, _layouts_full_shared_logo_Logo__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);













const Header = ()=>{
    const lgDown = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.useMediaQuery)((theme)=>theme.breakpoints.down("lg"));
    const lgUp = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.useMediaQuery)((theme)=>theme.breakpoints.up("lg"));
    // drawer
    const customizer = (0,_store_Store__WEBPACK_IMPORTED_MODULE_3__/* .useSelector */ .v9)((state)=>state.customizer);
    const dispatch = (0,_store_Store__WEBPACK_IMPORTED_MODULE_3__/* .useDispatch */ .I0)();
    const AppBarStyled = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.AppBar)(({ theme  })=>({
            background: theme.palette.background.paper,
            justifyContent: "center",
            backdropFilter: "blur(4px)",
            [theme.breakpoints.up("lg")]: {
                minHeight: customizer.TopbarHeight
            }
        }));
    const ToolbarStyled = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Toolbar)(({ theme  })=>({
            margin: "0 auto",
            width: "100%",
            color: `${theme.palette.text.secondary} !important`
        }));
    return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AppBarStyled, {
        position: "sticky",
        color: "default",
        elevation: 8,
        children: /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ToolbarStyled, {
            sx: {
                maxWidth: customizer.isLayout === "boxed" ? "lg" : "100%!important"
            },
            children: [
                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                    sx: {
                        width: lgDown ? "45px" : "auto",
                        overflow: "hidden"
                    },
                    children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_layouts_full_shared_logo_Logo__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {})
                }),
                lgDown ? /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
                    color: "inherit",
                    "aria-label": "menu",
                    onClick: ()=>dispatch((0,_store_customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_4__/* .toggleMobileSidebar */ .tW)()),
                    children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_5__.IconMenu2, {})
                }) : "",
                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_layouts_full_vertical_header_Search__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {}),
                lgUp ? /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_layouts_full_vertical_header_Navigation__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {})
                }) : null,
                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                    flexGrow: 1
                }),
                /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                    spacing: 1,
                    direction: "row",
                    alignItems: "center",
                    children: [
                        /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_layouts_full_vertical_header_Language__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_layouts_full_vertical_header_Cart__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_layouts_full_vertical_header_Notification__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_layouts_full_vertical_header_Profile__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {})
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5920:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2236);
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6517);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);


const Menuitems = [
    {
        id: (0,lodash__WEBPACK_IMPORTED_MODULE_1__.uniqueId)(),
        title: "Starter",
        icon: _tabler_icons_react__WEBPACK_IMPORTED_MODULE_0__.IconAperture,
        href: "/"
    },
    {
        id: (0,lodash__WEBPACK_IMPORTED_MODULE_1__.uniqueId)(),
        title: "Menu Level",
        icon: _tabler_icons_react__WEBPACK_IMPORTED_MODULE_0__.IconBoxMultiple,
        href: "/menulevel/",
        children: [
            {
                id: (0,lodash__WEBPACK_IMPORTED_MODULE_1__.uniqueId)(),
                title: "Level 1",
                icon: _tabler_icons_react__WEBPACK_IMPORTED_MODULE_0__.IconPoint,
                href: "/l1"
            },
            {
                id: (0,lodash__WEBPACK_IMPORTED_MODULE_1__.uniqueId)(),
                title: "Level 1.1",
                icon: _tabler_icons_react__WEBPACK_IMPORTED_MODULE_0__.IconPoint,
                href: "/l1.1",
                children: [
                    {
                        id: (0,lodash__WEBPACK_IMPORTED_MODULE_1__.uniqueId)(),
                        title: "Level 2",
                        icon: _tabler_icons_react__WEBPACK_IMPORTED_MODULE_0__.IconPoint,
                        href: "/l2"
                    },
                    {
                        id: (0,lodash__WEBPACK_IMPORTED_MODULE_1__.uniqueId)(),
                        title: "Level 2.1",
                        icon: _tabler_icons_react__WEBPACK_IMPORTED_MODULE_0__.IconPoint,
                        href: "/l2.1",
                        children: [
                            {
                                id: (0,lodash__WEBPACK_IMPORTED_MODULE_1__.uniqueId)(),
                                title: "Level 3",
                                icon: _tabler_icons_react__WEBPACK_IMPORTED_MODULE_0__.IconPoint,
                                href: "/l3"
                            },
                            {
                                id: (0,lodash__WEBPACK_IMPORTED_MODULE_1__.uniqueId)(),
                                title: "Level 3.1",
                                icon: _tabler_icons_react__WEBPACK_IMPORTED_MODULE_0__.IconPoint,
                                href: "/l3.1"
                            }
                        ]
                    }
                ]
            }
        ]
    }
];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Menuitems);


/***/ }),

/***/ 7931:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _store_Store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7404);
/* harmony import */ var _NavItem_NavItem__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7026);
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2236);
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _store_Store__WEBPACK_IMPORTED_MODULE_5__, _NavItem_NavItem__WEBPACK_IMPORTED_MODULE_6__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _store_Store__WEBPACK_IMPORTED_MODULE_5__, _NavItem_NavItem__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




// mui imports


// custom imports

// plugins

// FC Component For Dropdown Menu
const NavCollapse = ({ menu , level , pathWithoutLastPart , pathDirect , hideMenu  })=>{
    const Icon = menu.icon;
    const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__.useTheme)();
    const { pathname  } = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const [open, setOpen] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const customizer = (0,_store_Store__WEBPACK_IMPORTED_MODULE_5__/* .useSelector */ .v9)((state)=>state.customizer);
    const menuIcon = level > 1 ? /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Icon, {
        stroke: 1.5,
        size: "1rem"
    }) : /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Icon, {
        stroke: 1.5,
        size: "1.1rem"
    });
    react__WEBPACK_IMPORTED_MODULE_1___default().useEffect(()=>{
        setOpen(false);
        menu.children.forEach((item)=>{
            if (item.href === pathname) {
                setOpen(true);
            }
        });
    }, [
        pathname,
        menu.children
    ]);
    const ListItemStyled = (0,_mui_material__WEBPACK_IMPORTED_MODULE_4__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.ListItemButton)(()=>({
            width: "auto",
            padding: "5px 10px",
            position: "relative",
            flexGrow: "unset",
            gap: "10px",
            borderRadius: `${customizer.borderRadius}px`,
            whiteSpace: "nowrap",
            color: open || pathname.includes(menu.href) || level < 1 ? "white" : theme.palette.text.secondary,
            backgroundColor: open || pathname.includes(menu.href) ? theme.palette.primary.main : "",
            "&:hover": {
                backgroundColor: open || pathname.includes(menu.href) ? theme.palette.primary.main : theme.palette.primary.light
            },
            "&:hover > .SubNav": {
                display: "block"
            }
        }));
    const ListSubMenu = (0,_mui_material__WEBPACK_IMPORTED_MODULE_4__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Box)(()=>({
            display: "none",
            position: "absolute",
            top: level > 1 ? `0px` : "35px",
            left: level > 1 ? `${level + 228}px` : "0px",
            padding: "10px",
            width: "250px",
            color: theme.palette.text.primary,
            boxShadow: theme.shadows[8],
            backgroundColor: theme.palette.background.paper
        }));
    const listItemProps = {
        component: "li"
    };
    // If Menu has Children
    const submenus = menu.children?.map((item)=>{
        if (item.children) {
            return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NavCollapse, {
                menu: item,
                level: level + 1,
                pathWithoutLastPart: pathWithoutLastPart,
                pathDirect: pathDirect,
                hideMenu: hideMenu,
                onClick: undefined
            }, item.id);
        } else {
            return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_NavItem_NavItem__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                item: item,
                level: level + 1,
                pathDirect: pathDirect,
                hideMenu: hideMenu,
                onClick: function() {
                    throw new Error("Function not implemented.");
                }
            }, item.id);
        }
    });
    return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), {
        children: /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ListItemStyled, {
            ...listItemProps,
            selected: pathWithoutLastPart === menu.href,
            className: open ? "selected" : "",
            children: [
                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.ListItemIcon, {
                    sx: {
                        minWidth: "auto",
                        p: "3px 0",
                        color: "inherit"
                    },
                    children: menuIcon
                }),
                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.ListItemText, {
                    color: "inherit",
                    sx: {
                        mr: "auto"
                    },
                    children: menu.title
                }),
                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_7__.IconChevronDown, {
                    size: "1rem"
                }),
                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ListSubMenu, {
                    component: "ul",
                    className: "SubNav",
                    children: submenus
                })
            ]
        })
    }, menu.id);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavCollapse);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7026:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _store_Store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7404);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _store_Store__WEBPACK_IMPORTED_MODULE_4__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _store_Store__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



// mui imports


const NavItem = ({ item , level , pathDirect , onClick  })=>{
    const customizer = (0,_store_Store__WEBPACK_IMPORTED_MODULE_4__/* .useSelector */ .v9)((state)=>state.customizer);
    const Icon = item.icon;
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_3__.useTheme)();
    const itemIcon = level > 1 ? /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Icon, {
        stroke: 1.5,
        size: "1rem"
    }) : /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Icon, {
        stroke: 1.5,
        size: "1.1rem"
    });
    const ListItemStyled2 = (0,_mui_material__WEBPACK_IMPORTED_MODULE_3__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.ListItem)(()=>({
            padding: "5px 10px",
            gap: "10px",
            borderRadius: `${customizer.borderRadius}px`,
            marginBottom: level > 1 ? "3px" : "0px",
            color: level > 1 && pathDirect === item.href ? `${theme.palette.primary.main}!important` : theme.palette.text.secondary,
            "&:hover": {
                backgroundColor: theme.palette.primary.light
            },
            "&.Mui-selected": {
                color: level > 1 ? theme.palette.primary.main : "white!important",
                backgroundColor: level > 1 ? "transparent" : theme.palette.primary.main,
                "&:hover": {
                    backgroundColor: level > 1 ? "" : theme.palette.primary.main,
                    color: "white"
                }
            }
        }));
    const listItemProps = {
        component: item?.external ? "a" : (next_link__WEBPACK_IMPORTED_MODULE_2___default()),
        to: item?.href,
        href: item?.external ? item?.href : "",
        target: item?.external ? "_blank" : ""
    };
    return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.List, {
        component: "li",
        disablePadding: true,
        children: /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ListItemStyled2, {
            ...listItemProps,
            disabled: item.disabled,
            selected: pathDirect === item.href,
            onClick: onClick,
            children: [
                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.ListItemIcon, {
                    sx: {
                        minWidth: "auto",
                        p: "3px 0",
                        color: "inherit"
                    },
                    children: itemIcon
                }),
                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.ListItemText, {
                    children: item.title
                })
            ]
        })
    }, item.id);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavItem);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7795:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var _Menudata__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5920);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _store_Store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7404);
/* harmony import */ var _NavItem_NavItem__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7026);
/* harmony import */ var _NavCollapse_NavCollapse__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7931);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _store_Store__WEBPACK_IMPORTED_MODULE_4__, _NavItem_NavItem__WEBPACK_IMPORTED_MODULE_5__, _NavCollapse_NavCollapse__WEBPACK_IMPORTED_MODULE_6__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _store_Store__WEBPACK_IMPORTED_MODULE_4__, _NavItem_NavItem__WEBPACK_IMPORTED_MODULE_5__, _NavCollapse_NavCollapse__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const NavListing = ()=>{
    const { pathname  } = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const pathDirect = pathname;
    const pathWithoutLastPart = pathname.slice(0, pathname.lastIndexOf("/"));
    const customizer = (0,_store_Store__WEBPACK_IMPORTED_MODULE_4__/* .useSelector */ .v9)((state)=>state.customizer);
    const lgUp = (0,_mui_material__WEBPACK_IMPORTED_MODULE_3__.useMediaQuery)((theme)=>theme.breakpoints.up("lg"));
    const hideMenu = lgUp ? customizer.isCollapse && !customizer.isSidebarHover : "";
    return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
        children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.List, {
            sx: {
                p: 0,
                display: "flex",
                gap: "3px",
                zIndex: "100"
            },
            children: _Menudata__WEBPACK_IMPORTED_MODULE_1__/* ["default"].map */ .Z.map((item)=>{
                if (item.children) {
                    return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_NavCollapse_NavCollapse__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        menu: item,
                        pathDirect: pathDirect,
                        hideMenu: hideMenu,
                        pathWithoutLastPart: pathWithoutLastPart,
                        level: 1,
                        onClick: undefined
                    }, item.id);
                // {/********If Sub No Menu**********/}
                } else {
                    return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_NavItem_NavItem__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        item: item,
                        pathDirect: pathDirect,
                        hideMenu: hideMenu,
                        onClick: function() {
                            throw new Error("Function not implemented.");
                        }
                    }, item.id);
                }
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavListing);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6030:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _NavListing_NavListing__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7795);
/* harmony import */ var _shared_logo_Logo__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2095);
/* harmony import */ var _store_Store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7404);
/* harmony import */ var _store_customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9065);
/* harmony import */ var _vertical_sidebar_SidebarItems__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3476);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _NavListing_NavListing__WEBPACK_IMPORTED_MODULE_2__, _shared_logo_Logo__WEBPACK_IMPORTED_MODULE_3__, _store_Store__WEBPACK_IMPORTED_MODULE_4__, _vertical_sidebar_SidebarItems__WEBPACK_IMPORTED_MODULE_6__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _NavListing_NavListing__WEBPACK_IMPORTED_MODULE_2__, _shared_logo_Logo__WEBPACK_IMPORTED_MODULE_3__, _store_Store__WEBPACK_IMPORTED_MODULE_4__, _vertical_sidebar_SidebarItems__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const Navigation = ()=>{
    const lgUp = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)((theme)=>theme.breakpoints.up("lg"));
    const customizer = (0,_store_Store__WEBPACK_IMPORTED_MODULE_4__/* .useSelector */ .v9)((state)=>state.customizer);
    const dispatch = (0,_store_Store__WEBPACK_IMPORTED_MODULE_4__/* .useDispatch */ .I0)();
    if (lgUp) {
        return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
            sx: {
                borderBottom: "1px solid rgba(0,0,0,0.05)"
            },
            py: 2,
            children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Container, {
                sx: {
                    maxWidth: customizer.isLayout === "boxed" ? "lg" : "100%!important"
                },
                children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_NavListing_NavListing__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
            })
        });
    }
    return /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Drawer, {
        anchor: "left",
        open: customizer.isMobileSidebar,
        onClose: ()=>dispatch((0,_store_customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_5__/* .toggleMobileSidebar */ .tW)()),
        variant: "temporary",
        PaperProps: {
            sx: {
                width: customizer.SidebarWidth,
                border: "0 !important",
                boxShadow: (theme)=>theme.shadows[8]
            }
        },
        children: [
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                px: 2,
                children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_shared_logo_Logo__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
            }),
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_vertical_sidebar_SidebarItems__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Navigation);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7548:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _store_Store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7404);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(19);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2236);
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _store_customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9065);
/* harmony import */ var _components_custom_scroll_Scrollbar__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5917);
/* harmony import */ var _mui_icons_material_WbSunnyTwoTone__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3742);
/* harmony import */ var _mui_icons_material_WbSunnyTwoTone__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_WbSunnyTwoTone__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_icons_material_DarkModeTwoTone__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8408);
/* harmony import */ var _mui_icons_material_DarkModeTwoTone__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_DarkModeTwoTone__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_icons_material_SwipeLeftAltTwoTone__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9635);
/* harmony import */ var _mui_icons_material_SwipeLeftAltTwoTone__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_SwipeLeftAltTwoTone__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_icons_material_SwipeRightAltTwoTone__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8193);
/* harmony import */ var _mui_icons_material_SwipeRightAltTwoTone__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_SwipeRightAltTwoTone__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _mui_icons_material_AspectRatioTwoTone__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5645);
/* harmony import */ var _mui_icons_material_AspectRatioTwoTone__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_AspectRatioTwoTone__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _mui_icons_material_CallToActionTwoTone__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1021);
/* harmony import */ var _mui_icons_material_CallToActionTwoTone__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_CallToActionTwoTone__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _mui_icons_material_ViewSidebarTwoTone__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5580);
/* harmony import */ var _mui_icons_material_ViewSidebarTwoTone__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_ViewSidebarTwoTone__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _mui_icons_material_WebAssetTwoTone__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1349);
/* harmony import */ var _mui_icons_material_WebAssetTwoTone__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_WebAssetTwoTone__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _mui_icons_material__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(7915);
/* harmony import */ var _mui_icons_material__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material__WEBPACK_IMPORTED_MODULE_16__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _store_Store__WEBPACK_IMPORTED_MODULE_3__, _components_custom_scroll_Scrollbar__WEBPACK_IMPORTED_MODULE_7__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _store_Store__WEBPACK_IMPORTED_MODULE_3__, _components_custom_scroll_Scrollbar__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);

















const SidebarWidth = "320px";
const Customizer = ()=>{
    const [showDrawer, setShowDrawer] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const customizer = (0,_store_Store__WEBPACK_IMPORTED_MODULE_3__/* .useSelector */ .v9)((state)=>state.customizer);
    const dispatch = (0,_store_Store__WEBPACK_IMPORTED_MODULE_3__/* .useDispatch */ .I0)();
    const StyledBox = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.styled)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_4___default()))(({ theme  })=>({
            boxShadow: theme.shadows[8],
            padding: "20px",
            cursor: "pointer",
            justifyContent: "center",
            display: "flex",
            transition: "0.1s ease-in",
            border: "1px solid rgba(145, 158, 171, 0.12)",
            "&:hover": {
                transform: "scale(1.05)"
            }
        }));
    const thColors = [
        {
            id: 1,
            bgColor: "#5D87FF",
            disp: "BLUE_THEME"
        },
        {
            id: 2,
            bgColor: "#0074BA",
            disp: "AQUA_THEME"
        },
        {
            id: 3,
            bgColor: "#763EBD",
            disp: "PURPLE_THEME"
        },
        {
            id: 4,
            bgColor: "#0A7EA4",
            disp: "GREEN_THEME"
        },
        {
            id: 5,
            bgColor: "#01C0C8",
            disp: "CYAN_THEME"
        },
        {
            id: 6,
            bgColor: "#FA896B",
            disp: "ORANGE_THEME"
        }
    ];
    return /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Tooltip, {
                title: "Settings",
                children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Fab, {
                    color: "primary",
                    "aria-label": "settings",
                    sx: {
                        position: "fixed",
                        right: "25px",
                        bottom: "15px"
                    },
                    onClick: ()=>setShowDrawer(true),
                    children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_5__.IconSettings, {
                        stroke: 1.5
                    })
                })
            }),
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Drawer, {
                anchor: "right",
                open: showDrawer,
                onClose: ()=>setShowDrawer(false),
                PaperProps: {
                    sx: {
                        width: SidebarWidth
                    }
                },
                children: /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_custom_scroll_Scrollbar__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                    sx: {
                        height: "calc(100vh - 5px)"
                    },
                    children: [
                        /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_4___default()), {
                            p: 2,
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center",
                            children: [
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                    variant: "h4",
                                    children: "Settings"
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
                                    color: "inherit",
                                    onClick: ()=>setShowDrawer(false),
                                    children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_5__.IconX, {
                                        size: "1rem"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Divider, {}),
                        /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_4___default()), {
                            p: 3,
                            children: [
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                    variant: "h6",
                                    gutterBottom: true,
                                    children: "Theme Option"
                                }),
                                /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                                    direction: "row",
                                    gap: 2,
                                    my: 2,
                                    children: [
                                        /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledBox, {
                                            onClick: ()=>dispatch((0,_store_customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_6__/* .setDarkMode */ .C8)("light")),
                                            display: "flex",
                                            gap: 1,
                                            children: [
                                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_WbSunnyTwoTone__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                    color: customizer.activeMode === "light" ? "primary" : "inherit"
                                                }),
                                                "Light"
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledBox, {
                                            onClick: ()=>dispatch((0,_store_customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_6__/* .setDarkMode */ .C8)("dark")),
                                            display: "flex",
                                            gap: 1,
                                            children: [
                                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_DarkModeTwoTone__WEBPACK_IMPORTED_MODULE_9___default()), {
                                                    color: customizer.activeMode === "dark" ? "primary" : "inherit"
                                                }),
                                                "Dark"
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_4___default()), {
                                    pt: 3
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                    variant: "h6",
                                    gutterBottom: true,
                                    children: "Theme Direction"
                                }),
                                /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                                    direction: "row",
                                    gap: 2,
                                    my: 2,
                                    children: [
                                        /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledBox, {
                                            onClick: ()=>dispatch((0,_store_customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_6__/* .setDir */ .lv)("ltr")),
                                            display: "flex",
                                            gap: 1,
                                            children: [
                                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_SwipeLeftAltTwoTone__WEBPACK_IMPORTED_MODULE_10___default()), {
                                                    color: customizer.activeDir === "ltr" ? "primary" : "inherit"
                                                }),
                                                " ",
                                                "LTR"
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledBox, {
                                            onClick: ()=>dispatch((0,_store_customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_6__/* .setDir */ .lv)("rtl")),
                                            display: "flex",
                                            gap: 1,
                                            children: [
                                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_SwipeRightAltTwoTone__WEBPACK_IMPORTED_MODULE_11___default()), {
                                                    color: customizer.activeDir === "rtl" ? "primary" : "inherit"
                                                }),
                                                " ",
                                                "RTL"
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_4___default()), {
                                    pt: 3
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                    variant: "h6",
                                    gutterBottom: true,
                                    children: "Theme Colors"
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                    container: true,
                                    spacing: 2,
                                    children: thColors.map((thcolor)=>/*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                            item: true,
                                            xs: 4,
                                            children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledBox, {
                                                onClick: ()=>dispatch((0,_store_customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_6__/* .setTheme */ .Dc)(thcolor.disp)),
                                                children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Tooltip, {
                                                    title: `${thcolor.disp}`,
                                                    placement: "top",
                                                    children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                        sx: {
                                                            backgroundColor: thcolor.bgColor,
                                                            width: "25px",
                                                            height: "25px",
                                                            borderRadius: "60px",
                                                            alignItems: "center",
                                                            justifyContent: "center",
                                                            display: "flex",
                                                            color: "white"
                                                        },
                                                        "aria-label": `${thcolor.bgColor}`,
                                                        children: customizer.activeTheme === thcolor.disp ? /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_5__.IconCheck, {
                                                            width: 13
                                                        }) : ""
                                                    })
                                                })
                                            })
                                        }, thcolor.id))
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_4___default()), {
                                    pt: 4
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                    variant: "h6",
                                    gutterBottom: true,
                                    children: "Layout Type"
                                }),
                                /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                                    direction: "row",
                                    gap: 2,
                                    my: 2,
                                    children: [
                                        /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledBox, {
                                            onClick: ()=>dispatch((0,_store_customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_6__/* .toggleHorizontal */ .Sz)(false)),
                                            display: "flex",
                                            gap: 1,
                                            children: [
                                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_16__.ViewComfyTwoTone, {
                                                    color: customizer.isHorizontal === false ? "primary" : "inherit"
                                                }),
                                                "Vertical"
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledBox, {
                                            onClick: ()=>dispatch((0,_store_customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_6__/* .toggleHorizontal */ .Sz)(true)),
                                            display: "flex",
                                            gap: 1,
                                            children: [
                                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_16__.PaddingTwoTone, {
                                                    color: customizer.isHorizontal === true ? "primary" : "inherit"
                                                }),
                                                "Horizontal"
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_4___default()), {
                                    pt: 4
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                    variant: "h6",
                                    gutterBottom: true,
                                    children: "Container Option"
                                }),
                                /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                                    direction: "row",
                                    gap: 2,
                                    my: 2,
                                    children: [
                                        /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledBox, {
                                            onClick: ()=>dispatch((0,_store_customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_6__/* .toggleLayout */ .VE)("boxed")),
                                            display: "flex",
                                            gap: 1,
                                            children: [
                                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_CallToActionTwoTone__WEBPACK_IMPORTED_MODULE_13___default()), {
                                                    color: customizer.isLayout === "boxed" ? "primary" : "inherit"
                                                }),
                                                "Boxed"
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledBox, {
                                            onClick: ()=>dispatch((0,_store_customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_6__/* .toggleLayout */ .VE)("full")),
                                            display: "flex",
                                            gap: 1,
                                            children: [
                                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_AspectRatioTwoTone__WEBPACK_IMPORTED_MODULE_12___default()), {
                                                    color: customizer.isLayout === "full" ? "primary" : "inherit"
                                                }),
                                                "Full"
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_4___default()), {
                                    pt: 4
                                }),
                                customizer.isHorizontal ? "" : /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: [
                                        /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                            variant: "h6",
                                            gutterBottom: true,
                                            children: "Sidebar Type"
                                        }),
                                        /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                                            direction: "row",
                                            gap: 2,
                                            my: 2,
                                            children: [
                                                /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledBox, {
                                                    onClick: ()=>dispatch((0,_store_customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_6__/* .toggleSidebar */ .GB)()),
                                                    display: "flex",
                                                    gap: 1,
                                                    children: [
                                                        /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_WebAssetTwoTone__WEBPACK_IMPORTED_MODULE_15___default()), {
                                                            color: !customizer.isCollapse ? "primary" : "inherit"
                                                        }),
                                                        "Full"
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledBox, {
                                                    onClick: ()=>dispatch((0,_store_customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_6__/* .toggleSidebar */ .GB)()),
                                                    display: "flex",
                                                    gap: 1,
                                                    children: [
                                                        /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_ViewSidebarTwoTone__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                            color: customizer.isCollapse ? "primary" : "inherit"
                                                        }),
                                                        "mini"
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_4___default()), {
                                    pt: 4
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                    variant: "h6",
                                    gutterBottom: true,
                                    children: "Card With"
                                }),
                                /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                                    direction: "row",
                                    gap: 2,
                                    my: 2,
                                    children: [
                                        /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledBox, {
                                            onClick: ()=>dispatch((0,_store_customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_6__/* .setCardShadow */ .xu)(false)),
                                            display: "flex",
                                            gap: 1,
                                            children: [
                                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_16__.BorderOuter, {
                                                    color: !customizer.isCardShadow ? "primary" : "inherit"
                                                }),
                                                "Border"
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledBox, {
                                            onClick: ()=>dispatch((0,_store_customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_6__/* .setCardShadow */ .xu)(true)),
                                            display: "flex",
                                            gap: 1,
                                            children: [
                                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_CallToActionTwoTone__WEBPACK_IMPORTED_MODULE_13___default()), {
                                                    color: customizer.isCardShadow ? "primary" : "inherit"
                                                }),
                                                "Shadow"
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_4___default()), {
                                    pt: 4
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                    variant: "h6",
                                    gutterBottom: true,
                                    children: "Theme Border Radius"
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Slider, {
                                    size: "small",
                                    value: customizer.borderRadius,
                                    "aria-label": "Small",
                                    min: 4,
                                    max: 24,
                                    onChange: (event)=>dispatch((0,_store_customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_6__/* .setBorderRadius */ .Jh)(event.target.value)),
                                    valueLabelDisplay: "auto"
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Customizer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3630:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _emotion_cache__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1913);
/* harmony import */ var _emotion_cache__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_emotion_cache__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3139);
/* harmony import */ var stylis_plugin_rtl__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3195);
/* harmony import */ var stylis_plugin_rtl__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(stylis_plugin_rtl__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _emotion_react__WEBPACK_IMPORTED_MODULE_3__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _emotion_react__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const styleCache = ()=>_emotion_cache__WEBPACK_IMPORTED_MODULE_2___default()({
        key: "rtl",
        prepend: true,
        // We have to temporary ignore this due to incorrect definitions
        // in the stylis-plugin-rtl module
        // @see https://github.com/styled-components/stylis-plugin-rtl/issues/23
        stylisPlugins: [
            (stylis_plugin_rtl__WEBPACK_IMPORTED_MODULE_4___default())
        ]
    });
const RTL = (props)=>{
    const { children , direction  } = props;
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        document.dir = direction;
    }, [
        direction
    ]);
    if (direction === "rtl") {
        return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_emotion_react__WEBPACK_IMPORTED_MODULE_3__.CacheProvider, {
            value: styleCache(),
            children: children
        });
    }
    return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RTL);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 72:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _data__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5722);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__]);
_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const AppLinks = ()=>{
    return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        container: true,
        spacing: 3,
        mb: 4,
        children: _data__WEBPACK_IMPORTED_MODULE_2__/* .appsLink.map */ .V2.map((links, index)=>/*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                item: true,
                lg: 6,
                children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                    href: links.href,
                    className: "hover-text-primary",
                    children: /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                        direction: "row",
                        spacing: 2,
                        children: [
                            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                minWidth: "45px",
                                height: "45px",
                                bgcolor: "grey.100",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Avatar, {
                                    src: links.avatar,
                                    alt: links.avatar,
                                    sx: {
                                        width: 24,
                                        height: 24,
                                        borderRadius: 0
                                    }
                                })
                            }),
                            /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                children: [
                                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                        variant: "subtitle2",
                                        fontWeight: 600,
                                        color: "textPrimary",
                                        noWrap: true,
                                        className: "text-hover",
                                        sx: {
                                            width: "240px"
                                        },
                                        children: links.title
                                    }),
                                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                        color: "textSecondary",
                                        variant: "subtitle2",
                                        fontSize: "12px",
                                        sx: {
                                            width: "240px"
                                        },
                                        noWrap: true,
                                        children: links.subtext
                                    })
                                ]
                            })
                        ]
                    })
                })
            }, index))
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AppLinks);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1816:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6517);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2236);
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _store_Store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7404);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _CartItem__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3215);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _store_Store__WEBPACK_IMPORTED_MODULE_5__, _CartItem__WEBPACK_IMPORTED_MODULE_7__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _store_Store__WEBPACK_IMPORTED_MODULE_5__, _CartItem__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const Cart = ()=>{
    // Get Products
    const Cartproduct = (0,_store_Store__WEBPACK_IMPORTED_MODULE_5__/* .useSelector */ .v9)((state)=>state.ecommerceReducer.cart);
    const bcount = Cartproduct.length > 0 ? Cartproduct.length : "0";
    const checkout = (0,_store_Store__WEBPACK_IMPORTED_MODULE_5__/* .useSelector */ .v9)((state)=>state.ecommerceReducer.cart);
    const total = (0,lodash__WEBPACK_IMPORTED_MODULE_2__.sum)(checkout.map((product)=>product.price * product.qty));
    const [showDrawer, setShowDrawer] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const handleDrawerClose = ()=>{
        setShowDrawer(false);
    };
    const cartContent = /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Box, {
        children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Box, {
            children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CartItem__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {})
        })
    });
    return /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Box, {
        children: [
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.IconButton, {
                size: "large",
                color: "inherit",
                onClick: ()=>setShowDrawer(true),
                sx: {
                    color: "text.secondary",
                    ...showDrawer && {
                        color: "primary.main"
                    }
                },
                children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Badge, {
                    color: "error",
                    badgeContent: bcount,
                    children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_3__.IconShoppingCart, {
                        size: "21",
                        stroke: "1.5"
                    })
                })
            }),
            /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Drawer, {
                anchor: "right",
                open: showDrawer,
                onClose: ()=>setShowDrawer(false),
                PaperProps: {
                    sx: {
                        maxWidth: "500px"
                    }
                },
                children: [
                    /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Box, {
                        display: "flex",
                        alignItems: "center",
                        p: 3,
                        pb: 0,
                        justifyContent: "space-between",
                        children: [
                            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                variant: "h5",
                                fontWeight: 600,
                                children: "Shopping Cart"
                            }),
                            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Box, {
                                children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.IconButton, {
                                    color: "inherit",
                                    sx: {
                                        color: (theme)=>theme.palette.grey.A200
                                    },
                                    onClick: handleDrawerClose,
                                    children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_3__.IconX, {
                                        size: "1rem"
                                    })
                                })
                            })
                        ]
                    }),
                    cartContent,
                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Box, {
                        px: 3,
                        mt: 2,
                        children: Cartproduct.length > 0 ? /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: [
                                /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                                    direction: "row",
                                    justifyContent: "space-between",
                                    mb: 3,
                                    children: [
                                        /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                            variant: "subtitle2",
                                            fontWeight: 400,
                                            children: "Total"
                                        }),
                                        /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                            variant: "subtitle2",
                                            fontWeight: 600,
                                            children: [
                                                "$",
                                                total
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Button, {
                                    fullWidth: true,
                                    component: (next_link__WEBPACK_IMPORTED_MODULE_6___default()),
                                    href: "/apps/ecommerce/eco-checkout",
                                    variant: "contained",
                                    color: "primary",
                                    children: "Checkout"
                                })
                            ]
                        }) : ""
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Cart);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3215:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2236);
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _store_Store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7404);
/* harmony import */ var public_images_products_empty_shopping_cart_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5774);
/* harmony import */ var _store_apps_eCommerce_ECommerceSlice__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5615);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _store_Store__WEBPACK_IMPORTED_MODULE_4__, _store_apps_eCommerce_ECommerceSlice__WEBPACK_IMPORTED_MODULE_6__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _store_Store__WEBPACK_IMPORTED_MODULE_4__, _store_apps_eCommerce_ECommerceSlice__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const CartItems = ()=>{
    const dispatch = (0,_store_Store__WEBPACK_IMPORTED_MODULE_4__/* .useDispatch */ .I0)();
    // Get Products
    const Cartproduct = (0,_store_Store__WEBPACK_IMPORTED_MODULE_4__/* .useSelector */ .v9)((state)=>state.ecommerceReducer.cart);
    const Increase = (productId)=>{
        dispatch((0,_store_apps_eCommerce_ECommerceSlice__WEBPACK_IMPORTED_MODULE_6__/* .increment */ .nP)(productId));
    };
    const Decrease = (productId)=>{
        dispatch((0,_store_apps_eCommerce_ECommerceSlice__WEBPACK_IMPORTED_MODULE_6__/* .decrement */ .Mj)(productId));
    };
    return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
        px: 3,
        children: Cartproduct.length > 0 ? /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: Cartproduct.map((product, index)=>/*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                    children: /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                        direction: "row",
                        spacing: 2,
                        py: 3,
                        children: [
                            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Avatar, {
                                src: product.photo,
                                alt: product.photo,
                                sx: {
                                    borderRadius: "10px",
                                    height: "75px",
                                    width: "95px"
                                }
                            }),
                            /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                children: [
                                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                        variant: "subtitle2",
                                        color: "textPrimary",
                                        fontWeight: 600,
                                        children: product.title
                                    }),
                                    " ",
                                    /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                        color: "textSecondary",
                                        fontSize: "12px",
                                        children: [
                                            " ",
                                            product.category
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                                        direction: "row",
                                        alignItems: "center",
                                        spacing: 2,
                                        mt: "5px",
                                        children: [
                                            /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                variant: "subtitle2",
                                                fontWeight: "500",
                                                children: [
                                                    "$",
                                                    product.price * product.qty
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.ButtonGroup, {
                                                size: "small",
                                                "aria-label": "small button group",
                                                children: [
                                                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                                        color: "success",
                                                        className: "btn-xs",
                                                        variant: "text",
                                                        onClick: ()=>Decrease(product.id),
                                                        disabled: product.qty < 2,
                                                        children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_3__.IconMinus, {
                                                            stroke: 1.5,
                                                            size: "0.8rem"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                                        color: "inherit",
                                                        sx: {
                                                            bgcolor: "transparent",
                                                            color: "text.secondary"
                                                        },
                                                        variant: "text",
                                                        children: product.qty
                                                    }),
                                                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                                        color: "success",
                                                        className: "btn-xs",
                                                        variant: "text",
                                                        onClick: ()=>Increase(product.id),
                                                        children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_3__.IconPlus, {
                                                            stroke: 1.5,
                                                            size: "0.8rem"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                }, product.id + index * index))
        }) : /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
            textAlign: "center",
            mb: 3,
            children: [
                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_7___default()), {
                    src: public_images_products_empty_shopping_cart_svg__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z,
                    alt: "cart",
                    width: 200
                }),
                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                    variant: "h5",
                    mb: 2,
                    children: "Cart is Empty"
                }),
                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
                    component: (next_link__WEBPACK_IMPORTED_MODULE_2___default()),
                    href: "/apps/ecommerce/shop",
                    variant: "contained",
                    children: "Go back to Shopping"
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CartItems);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8677:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _store_Store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7404);
/* harmony import */ var _store_customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9065);
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2236);
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _Notification__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5893);
/* harmony import */ var _Profile__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8012);
/* harmony import */ var _Cart__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1816);
/* harmony import */ var _Language__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4383);
/* harmony import */ var _MobileRightSidebar__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5189);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _store_Store__WEBPACK_IMPORTED_MODULE_2__, _Notification__WEBPACK_IMPORTED_MODULE_5__, _Profile__WEBPACK_IMPORTED_MODULE_6__, _Cart__WEBPACK_IMPORTED_MODULE_7__, _Language__WEBPACK_IMPORTED_MODULE_8__, _MobileRightSidebar__WEBPACK_IMPORTED_MODULE_9__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _store_Store__WEBPACK_IMPORTED_MODULE_2__, _Notification__WEBPACK_IMPORTED_MODULE_5__, _Profile__WEBPACK_IMPORTED_MODULE_6__, _Cart__WEBPACK_IMPORTED_MODULE_7__, _Language__WEBPACK_IMPORTED_MODULE_8__, _MobileRightSidebar__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const Header = ()=>{
    const lgUp = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)((theme)=>theme.breakpoints.up("lg"));
    const lgDown = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)((theme)=>theme.breakpoints.down("lg"));
    // drawer
    const customizer = (0,_store_Store__WEBPACK_IMPORTED_MODULE_2__/* .useSelector */ .v9)((state)=>state.customizer);
    const dispatch = (0,_store_Store__WEBPACK_IMPORTED_MODULE_2__/* .useDispatch */ .I0)();
    const AppBarStyled = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.AppBar)(({ theme  })=>({
            boxShadow: "none",
            background: theme.palette.background.paper,
            justifyContent: "center",
            backdropFilter: "blur(4px)",
            [theme.breakpoints.up("lg")]: {
                minHeight: customizer.TopbarHeight
            }
        }));
    const ToolbarStyled = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Toolbar)(({ theme  })=>({
            width: "100%",
            color: theme.palette.text.secondary
        }));
    return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AppBarStyled, {
        position: "sticky",
        color: "default",
        children: /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ToolbarStyled, {
            children: [
                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.IconButton, {
                    color: "inherit",
                    "aria-label": "menu",
                    onClick: lgUp ? ()=>dispatch((0,_store_customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_3__/* .toggleSidebar */ .GB)()) : ()=>dispatch((0,_store_customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_3__/* .toggleMobileSidebar */ .tW)()),
                    children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_4__.IconMenu2, {
                        size: "20"
                    })
                }),
                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                    flexGrow: 1
                }),
                /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                    spacing: 1,
                    direction: "row",
                    alignItems: "center",
                    children: [
                        /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Language__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Cart__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Notification__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}),
                        lgDown ? /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_MobileRightSidebar__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {}) : null,
                        /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Profile__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4383:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _store_Store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7404);
/* harmony import */ var _store_customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9065);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7987);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _store_Store__WEBPACK_IMPORTED_MODULE_3__, react_i18next__WEBPACK_IMPORTED_MODULE_6__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _store_Store__WEBPACK_IMPORTED_MODULE_3__, react_i18next__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const Languages = [
    {
        flagname: "English (UK)",
        icon: "/images/flag/icon-flag-en.svg",
        value: "en"
    },
    // {
    //   flagname: '中国人 (Chinese)',
    //   icon: "/images/flag/icon-flag-cn.svg",
    //   value: 'ch',
    // },
    // {
    //   flagname: 'français (French)',
    //   icon: "/images/flag/icon-flag-fr.svg",
    //   value: 'fr',
    // },
    // {
    //   flagname: 'عربي (Arabic)',
    //   icon: "/images/flag/icon-flag-sa.svg",
    //   value: 'ar',
    // },
    {
        flagname: "Spanish (MX)",
        icon: "/images/flag/icon-flag-mx.png",
        value: "es"
    }
];
const Language = ()=>{
    const [anchorEl, setAnchorEl] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(null);
    const dispatch = (0,_store_Store__WEBPACK_IMPORTED_MODULE_3__/* .useDispatch */ .I0)();
    const open = Boolean(anchorEl);
    const customizer = (0,_store_Store__WEBPACK_IMPORTED_MODULE_3__/* .useSelector */ .v9)((state)=>state.customizer);
    const currentLang = Languages.find((_lang)=>_lang.value === customizer.isLanguage) || Languages[4];
    const { i18n  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_6__.useTranslation)();
    const handleClick = (event)=>{
        setAnchorEl(event.currentTarget);
    };
    const handleClose = ()=>{
        setAnchorEl(null);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        i18n.changeLanguage(customizer.isLanguage);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    return /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
                "aria-label": "more",
                id: "long-button",
                "aria-controls": open ? "long-menu" : undefined,
                "aria-expanded": open ? "true" : undefined,
                "aria-haspopup": "true",
                onClick: handleClick,
                children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Avatar, {
                    src: currentLang.icon,
                    alt: currentLang.value,
                    sx: {
                        width: 20,
                        height: 20
                    }
                })
            }),
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Menu, {
                id: "long-menu",
                anchorEl: anchorEl,
                open: open,
                onClose: handleClose,
                sx: {
                    "& .MuiMenu-paper": {
                        width: "200px"
                    }
                },
                children: Languages.map((option, index)=>/*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.MenuItem, {
                        sx: {
                            py: 2,
                            px: 3
                        },
                        onClick: ()=>dispatch((0,_store_customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_4__/* .setLanguage */ .m0)(option.value)),
                        children: /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_5__.Stack, {
                            direction: "row",
                            spacing: 1,
                            alignItems: "center",
                            children: [
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Avatar, {
                                    src: option.icon,
                                    alt: option.icon,
                                    sx: {
                                        width: 20,
                                        height: 20
                                    }
                                }),
                                /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                    children: [
                                        " ",
                                        option.flagname
                                    ]
                                })
                            ]
                        })
                    }, index))
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Language);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5189:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2236);
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _AppLinks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(72);
/* harmony import */ var _QuickLinks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3447);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _AppLinks__WEBPACK_IMPORTED_MODULE_5__, _QuickLinks__WEBPACK_IMPORTED_MODULE_6__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _AppLinks__WEBPACK_IMPORTED_MODULE_5__, _QuickLinks__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const MobileRightSidebar = ()=>{
    const [showDrawer, setShowDrawer] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [open, setOpen] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(true);
    const handleClick = ()=>{
        setOpen(!open);
    };
    const cartContent = /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
        children: [
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                px: 1,
                children: /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.List, {
                    sx: {
                        width: "100%",
                        maxWidth: 360,
                        bgcolor: "background.paper"
                    },
                    component: "nav",
                    "aria-labelledby": "nested-list-subheader",
                    children: [
                        /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.ListItemButton, {
                            component: (next_link__WEBPACK_IMPORTED_MODULE_4___default()),
                            href: "/apps/chats",
                            children: [
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.ListItemIcon, {
                                    sx: {
                                        minWidth: 35
                                    },
                                    children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_2__.IconMessages, {
                                        size: "21",
                                        stroke: "1.5"
                                    })
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.ListItemText, {
                                    children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                        variant: "subtitle2",
                                        fontWeight: 600,
                                        children: "Chats"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.ListItemButton, {
                            component: (next_link__WEBPACK_IMPORTED_MODULE_4___default()),
                            href: "/apps/calendar",
                            children: [
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.ListItemIcon, {
                                    sx: {
                                        minWidth: 35
                                    },
                                    children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_2__.IconCalendarEvent, {
                                        size: "21",
                                        stroke: "1.5"
                                    })
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.ListItemText, {
                                    children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                        variant: "subtitle2",
                                        fontWeight: 600,
                                        children: "Calendar"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.ListItemButton, {
                            component: (next_link__WEBPACK_IMPORTED_MODULE_4___default()),
                            href: "/apps/email",
                            children: [
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.ListItemIcon, {
                                    sx: {
                                        minWidth: 35
                                    },
                                    children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_2__.IconMail, {
                                        size: "21",
                                        stroke: "1.5"
                                    })
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.ListItemText, {
                                    children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                        variant: "subtitle2",
                                        fontWeight: 600,
                                        children: "Email"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.ListItemButton, {
                            onClick: handleClick,
                            children: [
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.ListItemIcon, {
                                    sx: {
                                        minWidth: 35
                                    },
                                    children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_2__.IconApps, {
                                        size: "21",
                                        stroke: "1.5"
                                    })
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.ListItemText, {
                                    children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                        variant: "subtitle2",
                                        fontWeight: 600,
                                        children: "Apps"
                                    })
                                }),
                                open ? /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_2__.IconChevronDown, {
                                    size: "21",
                                    stroke: "1.5"
                                }) : /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_2__.IconChevronUp, {
                                    size: "21",
                                    stroke: "1.5"
                                })
                            ]
                        }),
                        /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Collapse, {
                            in: open,
                            timeout: "auto",
                            unmountOnExit: true,
                            children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                px: 4,
                                pt: 3,
                                overflow: "hidden",
                                children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_AppLinks__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                px: 3,
                mt: 3,
                children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_QuickLinks__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
            })
        ]
    });
    return /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
        children: [
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.IconButton, {
                size: "large",
                color: "inherit",
                onClick: ()=>setShowDrawer(true),
                sx: {
                    ...showDrawer && {
                        color: "primary.main"
                    }
                },
                children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_2__.IconGridDots, {
                    size: "21",
                    stroke: "1.5"
                })
            }),
            /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Drawer, {
                anchor: "right",
                open: showDrawer,
                onClose: ()=>setShowDrawer(false),
                PaperProps: {
                    sx: {
                        width: "300px"
                    }
                },
                children: [
                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                        p: 3,
                        pb: 0,
                        children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                            variant: "h5",
                            fontWeight: 600,
                            children: "Navigation"
                        })
                    }),
                    cartContent
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MobileRightSidebar);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4838:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2236);
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _AppLinks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(72);
/* harmony import */ var _QuickLinks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3447);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _AppLinks__WEBPACK_IMPORTED_MODULE_5__, _QuickLinks__WEBPACK_IMPORTED_MODULE_6__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _AppLinks__WEBPACK_IMPORTED_MODULE_5__, _QuickLinks__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const AppDD = ()=>{
    const [anchorEl2, setAnchorEl2] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const handleClick2 = (event)=>{
        setAnchorEl2(event.currentTarget);
    };
    const handleClose2 = ()=>{
        setAnchorEl2(null);
    };
    return /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                children: [
                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        "aria-label": "show 11 new notifications",
                        color: "inherit",
                        variant: "text",
                        "aria-controls": "msgs-menu",
                        "aria-haspopup": "true",
                        sx: {
                            bgcolor: anchorEl2 ? "primary.light" : "",
                            color: anchorEl2 ? "primary.main" : (theme)=>theme.palette.text.secondary
                        },
                        onClick: handleClick2,
                        endIcon: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_4__.IconChevronDown, {
                            size: "15",
                            style: {
                                marginLeft: "-5px",
                                marginTop: "2px"
                            }
                        }),
                        children: "Apps"
                    }),
                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Menu, {
                        id: "msgs-menu",
                        anchorEl: anchorEl2,
                        keepMounted: true,
                        open: Boolean(anchorEl2),
                        onClose: handleClose2,
                        anchorOrigin: {
                            horizontal: "left",
                            vertical: "bottom"
                        },
                        transformOrigin: {
                            horizontal: "left",
                            vertical: "top"
                        },
                        sx: {
                            "& .MuiMenu-paper": {
                                width: "850px"
                            },
                            "& .MuiMenu-paper ul": {
                                p: 0
                            }
                        },
                        children: /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                            container: true,
                            children: [
                                /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                    item: true,
                                    sm: 8,
                                    display: "flex",
                                    children: [
                                        /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                            p: 4,
                                            pr: 0,
                                            pb: 3,
                                            children: [
                                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_AppLinks__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}),
                                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Divider, {}),
                                                /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                                    sx: {
                                                        display: {
                                                            xs: "none",
                                                            sm: "flex"
                                                        }
                                                    },
                                                    alignItems: "center",
                                                    justifyContent: "space-between",
                                                    pt: 2,
                                                    pr: 4,
                                                    children: [
                                                        /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                            href: "/faq",
                                                            children: /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                                                variant: "subtitle2",
                                                                fontWeight: "600",
                                                                color: "textPrimary",
                                                                display: "flex",
                                                                alignItems: "center",
                                                                gap: "4px",
                                                                children: [
                                                                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_4__.IconHelp, {
                                                                        width: 24
                                                                    }),
                                                                    "Frequently Asked Questions"
                                                                ]
                                                            })
                                                        }),
                                                        /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                                            variant: "contained",
                                                            color: "primary",
                                                            children: "Check"
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Divider, {
                                            orientation: "vertical"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                    item: true,
                                    sm: 4,
                                    children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                        p: 4,
                                        children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_QuickLinks__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
                                    })
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                color: "inherit",
                sx: {
                    color: (theme)=>theme.palette.text.secondary
                },
                variant: "text",
                href: "",
                component: (next_link__WEBPACK_IMPORTED_MODULE_3___default()),
                children: "Chat"
            }),
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                color: "inherit",
                sx: {
                    color: (theme)=>theme.palette.text.secondary
                },
                variant: "text",
                href: "",
                component: (next_link__WEBPACK_IMPORTED_MODULE_3___default()),
                children: "Calendar"
            }),
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                color: "inherit",
                sx: {
                    color: (theme)=>theme.palette.text.secondary
                },
                variant: "text",
                href: "",
                component: (next_link__WEBPACK_IMPORTED_MODULE_3___default()),
                children: "Email"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AppDD);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5893:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _data__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5722);
/* harmony import */ var _components_custom_scroll_Scrollbar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5917);
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2236);
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _components_custom_scroll_Scrollbar__WEBPACK_IMPORTED_MODULE_4__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _components_custom_scroll_Scrollbar__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const Notifications = ()=>{
    const [anchorEl2, setAnchorEl2] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const handleClick2 = (event)=>{
        setAnchorEl2(event.currentTarget);
    };
    const handleClose2 = ()=>{
        setAnchorEl2(null);
    };
    return /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
        children: [
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
                size: "large",
                "aria-label": "show 11 new notifications",
                color: "inherit",
                "aria-controls": "msgs-menu",
                "aria-haspopup": "true",
                sx: {
                    color: anchorEl2 ? "primary.main" : "text.secondary"
                },
                onClick: handleClick2,
                children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Badge, {
                    variant: "dot",
                    color: "primary",
                    children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_5__.IconBellRinging, {
                        size: "21",
                        stroke: "1.5"
                    })
                })
            }),
            /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Menu, {
                id: "msgs-menu",
                anchorEl: anchorEl2,
                keepMounted: true,
                open: Boolean(anchorEl2),
                onClose: handleClose2,
                anchorOrigin: {
                    horizontal: "right",
                    vertical: "bottom"
                },
                transformOrigin: {
                    horizontal: "right",
                    vertical: "top"
                },
                sx: {
                    "& .MuiMenu-paper": {
                        width: "360px"
                    }
                },
                children: [
                    /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_6__.Stack, {
                        direction: "row",
                        py: 2,
                        px: 4,
                        justifyContent: "space-between",
                        alignItems: "center",
                        children: [
                            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                variant: "h6",
                                children: "Notifications"
                            }),
                            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Chip, {
                                label: "5 new",
                                color: "primary",
                                size: "small"
                            })
                        ]
                    }),
                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_custom_scroll_Scrollbar__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        sx: {
                            height: "385px"
                        },
                        children: _data__WEBPACK_IMPORTED_MODULE_3__/* .notifications.map */ .N9.map((notification, index)=>/*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.MenuItem, {
                                    sx: {
                                        py: 2,
                                        px: 4
                                    },
                                    children: /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_6__.Stack, {
                                        direction: "row",
                                        spacing: 2,
                                        children: [
                                            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Avatar, {
                                                src: notification.avatar,
                                                alt: notification.avatar,
                                                sx: {
                                                    width: 48,
                                                    height: 48
                                                }
                                            }),
                                            /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                                children: [
                                                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                                        variant: "subtitle2",
                                                        color: "textPrimary",
                                                        fontWeight: 600,
                                                        noWrap: true,
                                                        sx: {
                                                            width: "240px"
                                                        },
                                                        children: notification.title
                                                    }),
                                                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                                        color: "textSecondary",
                                                        variant: "subtitle2",
                                                        sx: {
                                                            width: "240px"
                                                        },
                                                        noWrap: true,
                                                        children: notification.subtitle
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            }, index))
                    }),
                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                        p: 3,
                        pb: 1,
                        children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                            href: "/apps/email",
                            variant: "outlined",
                            component: (next_link__WEBPACK_IMPORTED_MODULE_7___default()),
                            color: "primary",
                            fullWidth: true,
                            children: "See all Notifications"
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Notifications);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8012:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _data__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5722);
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2236);
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7987);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, react_i18next__WEBPACK_IMPORTED_MODULE_7__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, react_i18next__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const Profile = ()=>{
    const [anchorEl2, setAnchorEl2] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_7__.useTranslation)();
    const handleClick2 = (event)=>{
        setAnchorEl2(event.currentTarget);
    };
    const handleClose2 = ()=>{
        setAnchorEl2(null);
    };
    return /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
        children: [
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.IconButton, {
                size: "large",
                "aria-label": "show 11 new notifications",
                color: "inherit",
                "aria-controls": "msgs-menu",
                "aria-haspopup": "true",
                sx: {
                    ...typeof anchorEl2 === "object" && {
                        color: "primary.main"
                    }
                },
                onClick: handleClick2,
                children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Avatar, {
                    src: "/images/profile/user-1.jpg",
                    alt: "ProfileImg",
                    sx: {
                        width: 35,
                        height: 35
                    }
                })
            }),
            /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Menu, {
                id: "msgs-menu",
                anchorEl: anchorEl2,
                keepMounted: true,
                open: Boolean(anchorEl2),
                onClose: handleClose2,
                anchorOrigin: {
                    horizontal: "right",
                    vertical: "bottom"
                },
                transformOrigin: {
                    horizontal: "right",
                    vertical: "top"
                },
                sx: {
                    "& .MuiMenu-paper": {
                        width: "360px",
                        p: 4
                    }
                },
                children: [
                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                        variant: "h5",
                        children: "User Profile"
                    }),
                    /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_6__.Stack, {
                        direction: "row",
                        py: 3,
                        spacing: 2,
                        alignItems: "center",
                        children: [
                            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Avatar, {
                                src: "/profile/user-1.jpg",
                                alt: "ProfileImg",
                                sx: {
                                    width: 95,
                                    height: 95
                                }
                            }),
                            /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                children: [
                                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                        variant: "subtitle2",
                                        color: "textPrimary",
                                        fontWeight: 600,
                                        children: "Sonia Perez"
                                    }),
                                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                        variant: "subtitle2",
                                        color: "textSecondary",
                                        children: t(`${"Costemologist"}`)
                                    }),
                                    /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                        variant: "subtitle2",
                                        color: "textSecondary",
                                        display: "flex",
                                        alignItems: "center",
                                        gap: 1,
                                        children: [
                                            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_5__.IconMail, {
                                                width: 15,
                                                height: 15
                                            }),
                                            "info@modernize.com"
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Divider, {}),
                    _data__WEBPACK_IMPORTED_MODULE_4__/* .profile.map */ .N5.map((profile)=>/*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                            children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                sx: {
                                    py: 2,
                                    px: 0
                                },
                                className: "hover-text-primary",
                                children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: profile.href,
                                    children: /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_6__.Stack, {
                                        direction: "row",
                                        spacing: 2,
                                        children: [
                                            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                                width: "45px",
                                                height: "45px",
                                                bgcolor: "primary.light",
                                                display: "flex",
                                                alignItems: "center",
                                                justifyContent: "center",
                                                children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Avatar, {
                                                    src: profile.icon,
                                                    alt: profile.icon,
                                                    sx: {
                                                        width: 24,
                                                        height: 24,
                                                        borderRadius: 0
                                                    }
                                                })
                                            }),
                                            /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                                children: [
                                                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                        variant: "subtitle2",
                                                        fontWeight: 600,
                                                        color: "textPrimary",
                                                        className: "text-hover",
                                                        noWrap: true,
                                                        sx: {
                                                            width: "240px"
                                                        },
                                                        children: profile.title
                                                    }),
                                                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                        color: "textSecondary",
                                                        variant: "subtitle2",
                                                        sx: {
                                                            width: "240px"
                                                        },
                                                        noWrap: true,
                                                        children: profile.subtitle
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            })
                        }, profile.title)),
                    /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                        mt: 2,
                        children: [
                            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                bgcolor: "primary.light",
                                p: 3,
                                mb: 3,
                                overflow: "hidden",
                                position: "relative",
                                children: /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                    display: "flex",
                                    justifyContent: "space-between",
                                    children: [
                                        /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                            children: [
                                                /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                    variant: "h5",
                                                    mb: 2,
                                                    children: [
                                                        "Unlimited ",
                                                        /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                        "Access"
                                                    ]
                                                }),
                                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Button, {
                                                    variant: "contained",
                                                    color: "primary",
                                                    children: "Upgrade"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: "/backgrounds/unlimited-bg.png",
                                            alt: "unlimited",
                                            className: "signup-bg",
                                            width: 150,
                                            height: 183
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Button, {
                                href: "/auth/auth1/login",
                                variant: "outlined",
                                color: "primary",
                                component: (next_link__WEBPACK_IMPORTED_MODULE_2___default()),
                                fullWidth: true,
                                children: "Logout"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Profile);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3447:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _data__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5722);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__]);
_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const QuickLinks = ()=>{
    return /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                variant: "h5",
                children: "Quick Links"
            }),
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                spacing: 2,
                mt: 2,
                children: _data__WEBPACK_IMPORTED_MODULE_2__/* .pageLinks.map */ .Nc.map((pagelink, index)=>/*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                        href: pagelink.href,
                        className: "hover-text-primary",
                        children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                            variant: "subtitle2",
                            color: "textPrimary",
                            className: "text-hover",
                            fontWeight: 600,
                            children: pagelink.title
                        })
                    }, index))
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (QuickLinks);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8805:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2236);
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _sidebar_MenuItems__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3130);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__]);
_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const Search = ()=>{
    // drawer top
    const [showDrawer2, setShowDrawer2] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [search, setSerach] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const handleDrawerClose2 = ()=>{
        setShowDrawer2(false);
    };
    const filterRoutes = (rotr, cSearch)=>{
        if (rotr.length > 1) return rotr.filter((t)=>t.title ? t.href.toLocaleLowerCase().includes(cSearch.toLocaleLowerCase()) : "");
        return rotr;
    };
    const searchData = filterRoutes(_sidebar_MenuItems__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, search);
    return /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
                "aria-label": "show 4 new mails",
                color: "inherit",
                "aria-controls": "search-menu",
                "aria-haspopup": "true",
                onClick: ()=>setShowDrawer2(true),
                size: "large",
                children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_3__.IconSearch, {
                    size: "16"
                })
            }),
            /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Dialog, {
                open: showDrawer2,
                onClose: ()=>setShowDrawer2(false),
                fullWidth: true,
                maxWidth: "sm",
                "aria-labelledby": "alert-dialog-title",
                "aria-describedby": "alert-dialog-description",
                PaperProps: {
                    sx: {
                        position: "fixed",
                        top: 30,
                        m: 0
                    }
                },
                children: [
                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.DialogContent, {
                        className: "testdialog",
                        children: /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                            direction: "row",
                            spacing: 2,
                            alignItems: "center",
                            children: [
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, {
                                    id: "tb-search",
                                    placeholder: "Search here",
                                    fullWidth: true,
                                    onChange: (e)=>setSerach(e.target.value),
                                    inputProps: {
                                        "aria-label": "Search here"
                                    }
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
                                    size: "small",
                                    onClick: handleDrawerClose2,
                                    children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_3__.IconX, {
                                        size: "18"
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Divider, {}),
                    /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                        p: 2,
                        sx: {
                            maxHeight: "60vh",
                            overflow: "auto"
                        },
                        children: [
                            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                variant: "h5",
                                p: 1,
                                children: "Quick Page Links"
                            }),
                            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.List, {
                                    component: "nav",
                                    children: searchData.map((menu)=>{
                                        return /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                            children: [
                                                menu.title && !menu.children ? /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.ListItemButton, {
                                                    sx: {
                                                        py: 0.5,
                                                        px: 1
                                                    },
                                                    href: menu?.href,
                                                    component: (next_link__WEBPACK_IMPORTED_MODULE_5___default()),
                                                    children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.ListItemText, {
                                                        primary: menu.title,
                                                        secondary: menu?.href,
                                                        sx: {
                                                            my: 0,
                                                            py: 0.5
                                                        }
                                                    })
                                                }) : "",
                                                menu.children ? /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                    children: menu.children.map((child)=>{
                                                        return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.ListItemButton, {
                                                            sx: {
                                                                py: 0.5,
                                                                px: 1
                                                            },
                                                            href: child.href,
                                                            component: (next_link__WEBPACK_IMPORTED_MODULE_5___default()),
                                                            children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.ListItemText, {
                                                                primary: child.title,
                                                                secondary: child.href,
                                                                sx: {
                                                                    my: 0,
                                                                    py: 0.5
                                                                }
                                                            })
                                                        }, child.title ? child.id : menu.subheader);
                                                    })
                                                }) : ""
                                            ]
                                        }, menu.title ? menu.id : menu.subheader);
                                    })
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Search);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5722:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "N5": () => (/* binding */ profile),
/* harmony export */   "N9": () => (/* binding */ notifications),
/* harmony export */   "Nc": () => (/* binding */ pageLinks),
/* harmony export */   "V2": () => (/* binding */ appsLink)
/* harmony export */ });
// Notifications dropdown
const notifications = [
    {
        avatar: "/images/profile/user-1.jpg",
        title: "Roman Joined the Team!",
        subtitle: "Congratulate him"
    },
    {
        avatar: "/images/profile/user-2.jpg",
        title: "New message received",
        subtitle: "Salma sent you new message"
    },
    {
        avatar: "/images/profile/user-3.jpg",
        title: "New Payment received",
        subtitle: "Check your earnings"
    },
    {
        avatar: "/images/profile/user-4.jpg",
        title: "Jolly completed tasks",
        subtitle: "Assign her new tasks"
    },
    {
        avatar: "/images/profile/user-1.jpg",
        title: "Roman Joined the Team!",
        subtitle: "Congratulate him"
    },
    {
        avatar: "/images/profile/user-2.jpg",
        title: "New message received",
        subtitle: "Salma sent you new message"
    },
    {
        avatar: "/images/profile/user-3.jpg",
        title: "New Payment received",
        subtitle: "Check your earnings"
    },
    {
        avatar: "/images/profile/user-4.jpg",
        title: "Jolly completed tasks",
        subtitle: "Assign her new tasks"
    }
];
const profile = [
    {
        href: "",
        title: "My Profile",
        subtitle: "Account Settings",
        icon: "/images/svgs/icon-account.svg"
    },
    {
        href: "",
        title: "My Inbox",
        subtitle: "Messages & Emails",
        icon: "/images/svgs/icon-inbox.svg"
    },
    {
        href: "",
        title: "My Tasks",
        subtitle: "To-do and Daily Tasks",
        icon: "/images/svgs/icon-tasks.svg"
    }
];
const appsLink = [
    {
        href: "",
        title: "Chat Application",
        subtext: "New messages arrived",
        avatar: "/images/svgs/icon-dd-chat.svg"
    },
    {
        href: "",
        title: "eCommerce App",
        subtext: "New stock available",
        avatar: "/images/svgs/icon-dd-cart.svg"
    },
    {
        href: "",
        title: "Notes App",
        subtext: "To-do and Daily tasks",
        avatar: "/images/svgs/icon-dd-invoice.svg"
    },
    {
        href: "",
        title: "Calendar App",
        subtext: "Get dates",
        avatar: "/images/svgs/icon-dd-date.svg"
    },
    {
        href: "",
        title: "Contact Application",
        subtext: "2 Unsaved Contacts",
        avatar: "/images/svgs/icon-dd-mobile.svg"
    },
    {
        href: "",
        title: "Tickets App",
        subtext: "Submit tickets",
        avatar: "/images/svgs/icon-dd-lifebuoy.svg"
    },
    {
        href: "",
        title: "Email App",
        subtext: "Get new emails",
        avatar: "/images/svgs/icon-dd-message-box.svg"
    },
    {
        href: "",
        title: "Blog App",
        subtext: "added new blog",
        avatar: "/images/svgs/icon-dd-application.svg"
    }
];
const pageLinks = [
    {
        href: "",
        title: "Pricing Page"
    },
    {
        href: "",
        title: "Authentication Design"
    },
    {
        href: "",
        title: "Register Now"
    },
    {
        href: "",
        title: "404 Error Page"
    },
    {
        href: "",
        title: "Notes App"
    },
    {
        href: "",
        title: "User Application"
    },
    {
        href: "",
        title: "Blog Design"
    },
    {
        href: "",
        title: "Shopping Cart"
    }
];



/***/ }),

/***/ 3130:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6517);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2236);
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_1__);


const Menuitems = [
    {
        navlabel: true,
        subheader: "Home"
    },
    {
        id: (0,lodash__WEBPACK_IMPORTED_MODULE_0__.uniqueId)(),
        title: "Starter",
        icon: _tabler_icons_react__WEBPACK_IMPORTED_MODULE_1__.IconAperture,
        href: "/",
        chip: "New",
        chipColor: "secondary"
    },
    {
        navlabel: true,
        subheader: "Patients"
    },
    {
        id: (0,lodash__WEBPACK_IMPORTED_MODULE_0__.uniqueId)(),
        title: "Patient List",
        icon: _tabler_icons_react__WEBPACK_IMPORTED_MODULE_1__.IconList,
        href: "/patients/list"
    },
    {
        id: (0,lodash__WEBPACK_IMPORTED_MODULE_0__.uniqueId)(),
        title: "Patient Register",
        icon: _tabler_icons_react__WEBPACK_IMPORTED_MODULE_1__.IconPlus,
        href: "/patients/register"
    },
    {
        navlabel: true,
        subheader: "Proceedings"
    },
    {
        id: (0,lodash__WEBPACK_IMPORTED_MODULE_0__.uniqueId)(),
        title: "Create Proceedings",
        icon: _tabler_icons_react__WEBPACK_IMPORTED_MODULE_1__.IconPlus,
        href: "/proceedings"
    }
];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Menuitems);


/***/ }),

/***/ 4344:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _store_Store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7404);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _NavItem__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2060);
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2236);
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7987);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _store_Store__WEBPACK_IMPORTED_MODULE_2__, _NavItem__WEBPACK_IMPORTED_MODULE_5__, react_i18next__WEBPACK_IMPORTED_MODULE_7__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _store_Store__WEBPACK_IMPORTED_MODULE_2__, _NavItem__WEBPACK_IMPORTED_MODULE_5__, react_i18next__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





// mui imports

// custom imports

// plugins


// FC Component For Dropdown Menu
const NavCollapse = ({ menu , level , pathWithoutLastPart , pathDirect , hideMenu , onClick  })=>{
    const customizer = (0,_store_Store__WEBPACK_IMPORTED_MODULE_2__/* .useSelector */ .v9)((state)=>state.customizer);
    const Icon = menu?.icon;
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_4__.useTheme)();
    const { pathname  } = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_7__.useTranslation)();
    const [open, setOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const menuIcon = level > 1 ? /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Icon, {
        stroke: 1.5,
        size: "1rem"
    }) : /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Icon, {
        stroke: 1.5,
        size: "1.3rem"
    });
    const handleClick = ()=>{
        setOpen(!open);
    };
    // menu collapse for sub-levels
    react__WEBPACK_IMPORTED_MODULE_1___default().useEffect(()=>{
        setOpen(false);
        menu?.children?.forEach((item)=>{
            if (item?.href === pathname) {
                setOpen(true);
            }
        });
    }, [
        pathname,
        menu.children
    ]);
    const ListItemStyled = (0,_mui_material__WEBPACK_IMPORTED_MODULE_4__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.ListItemButton)(()=>({
            marginBottom: "2px",
            padding: "8px 10px",
            paddingLeft: hideMenu ? "10px" : level > 2 ? `${level * 15}px` : "10px",
            backgroundColor: open && level < 2 ? theme.palette.primary.main : "",
            whiteSpace: "nowrap",
            "&:hover": {
                backgroundColor: pathname.includes(menu.href) || open ? theme.palette.primary.main : theme.palette.primary.light,
                color: pathname.includes(menu.href) || open ? "white" : theme.palette.primary.main
            },
            color: open && level < 2 ? "white" :  true && level > 1 && open ? theme.palette.primary.main : theme.palette.text.secondary,
            borderRadius: `${customizer.borderRadius}px`
        }));
    // If Menu has Children
    const submenus = menu.children?.map((item)=>{
        if (item.children) {
            return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NavCollapse, {
                menu: item,
                level: level + 1,
                pathWithoutLastPart: pathWithoutLastPart,
                pathDirect: pathDirect,
                hideMenu: hideMenu,
                onClick: onClick
            }, item?.id);
        } else {
            return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_NavItem__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                item: item,
                level: level + 1,
                pathDirect: pathDirect,
                hideMenu: hideMenu,
                onClick: onClick
            }, item.id);
        }
    });
    return /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ListItemStyled, {
                onClick: handleClick,
                selected: pathWithoutLastPart === menu.href,
                children: [
                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.ListItemIcon, {
                        sx: {
                            minWidth: "36px",
                            p: "3px 0",
                            color: "inherit"
                        },
                        children: menuIcon
                    }),
                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.ListItemText, {
                        color: "inherit",
                        children: hideMenu ? "" : /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: t(`${menu.title}`)
                        })
                    }),
                    !open ? /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_6__.IconChevronDown, {
                        size: "1rem"
                    }) : /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_6__.IconChevronUp, {
                        size: "1rem"
                    })
                ]
            }, menu?.id),
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Collapse, {
                in: open,
                timeout: "auto",
                unmountOnExit: true,
                children: submenus
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavCollapse);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2429:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2236);
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7987);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, react_i18next__WEBPACK_IMPORTED_MODULE_4__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, react_i18next__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const NavGroup = ({ item , hideMenu  })=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
    const ListSubheaderStyle = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.styled)((props)=>/*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.ListSubheader, {
            disableSticky: true,
            ...props
        }))(({ theme  })=>({
            ...theme.typography.overline,
            fontWeight: "700",
            marginTop: theme.spacing(3),
            marginBottom: theme.spacing(0),
            color: "text.Primary",
            lineHeight: "26px",
            padding: "3px 12px",
            marginLeft: hideMenu ? "" : "-10px"
        }));
    return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ListSubheaderStyle, {
        children: hideMenu ? /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_2__.IconDots, {
            size: "14"
        }) : t(`${item?.subheader}`)
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavGroup);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2060:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _store_Store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7404);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7987);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _store_Store__WEBPACK_IMPORTED_MODULE_4__, react_i18next__WEBPACK_IMPORTED_MODULE_5__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _store_Store__WEBPACK_IMPORTED_MODULE_4__, react_i18next__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



// mui imports



const NavItem = ({ item , level , pathDirect , hideMenu , onClick  })=>{
    const customizer = (0,_store_Store__WEBPACK_IMPORTED_MODULE_4__/* .useSelector */ .v9)((state)=>state.customizer);
    const Icon = item?.icon;
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_3__.useTheme)();
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_5__.useTranslation)();
    const itemIcon = level > 1 ? /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Icon, {
        stroke: 1.5,
        size: "1rem"
    }) : /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Icon, {
        stroke: 1.5,
        size: "1.3rem"
    });
    const ListItemStyled = (0,_mui_material__WEBPACK_IMPORTED_MODULE_3__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.ListItemButton)(()=>({
            whiteSpace: "nowrap",
            marginBottom: "2px",
            padding: "8px 10px",
            borderRadius: `${customizer.borderRadius}px`,
            backgroundColor: level > 1 ? "transparent !important" : "inherit",
            color: level > 1 && pathDirect === item?.href ? `${theme.palette.primary.main}!important` : theme.palette.text.secondary,
            paddingLeft: hideMenu ? "10px" : level > 2 ? `${level * 15}px` : "10px",
            "&:hover": {
                backgroundColor: theme.palette.primary.light,
                color: theme.palette.primary.main
            },
            "&.Mui-selected": {
                color: "white",
                backgroundColor: theme.palette.primary.main,
                "&:hover": {
                    backgroundColor: theme.palette.primary.main,
                    color: "white"
                }
            }
        }));
    const listItemProps = {
        component: item?.external ? "a" : (next_link__WEBPACK_IMPORTED_MODULE_2___default()),
        to: item?.href,
        href: item?.external ? item?.href : "",
        target: item?.external ? "_blank" : ""
    };
    return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.List, {
        component: "li",
        disablePadding: true,
        children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
            href: item.href,
            children: /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ListItemStyled, {
                // {...listItemProps}
                disabled: item?.disabled,
                selected: pathDirect === item?.href,
                onClick: onClick,
                children: [
                    /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.ListItemIcon, {
                        sx: {
                            minWidth: "36px",
                            p: "3px 0",
                            color: level > 1 && pathDirect === item?.href ? `${theme.palette.primary.main}!important` : "inherit"
                        },
                        children: itemIcon
                    }),
                    /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.ListItemText, {
                        children: [
                            hideMenu ? "" : /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: t(`${item?.title}`)
                            }),
                            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            item?.subtitle ? /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                variant: "caption",
                                children: hideMenu ? "" : item?.subtitle
                            }) : ""
                        ]
                    }),
                    !item?.chip || hideMenu ? null : /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Chip, {
                        color: item?.chipColor,
                        variant: item?.variant ? item?.variant : "filled",
                        size: "small",
                        label: item?.chip
                    })
                ]
            })
        })
    }, item?.id && item.title);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavItem);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5294:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _SidebarItems__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3476);
/* harmony import */ var _shared_logo_Logo__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2095);
/* harmony import */ var _store_Store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7404);
/* harmony import */ var _store_customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9065);
/* harmony import */ var _components_custom_scroll_Scrollbar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5917);
/* harmony import */ var _SidebarProfile_Profile__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4149);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _SidebarItems__WEBPACK_IMPORTED_MODULE_2__, _shared_logo_Logo__WEBPACK_IMPORTED_MODULE_3__, _store_Store__WEBPACK_IMPORTED_MODULE_4__, _components_custom_scroll_Scrollbar__WEBPACK_IMPORTED_MODULE_6__, _SidebarProfile_Profile__WEBPACK_IMPORTED_MODULE_7__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _SidebarItems__WEBPACK_IMPORTED_MODULE_2__, _shared_logo_Logo__WEBPACK_IMPORTED_MODULE_3__, _store_Store__WEBPACK_IMPORTED_MODULE_4__, _components_custom_scroll_Scrollbar__WEBPACK_IMPORTED_MODULE_6__, _SidebarProfile_Profile__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const Sidebar = ()=>{
    const lgUp = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)((theme)=>theme.breakpoints.up("lg"));
    const customizer = (0,_store_Store__WEBPACK_IMPORTED_MODULE_4__/* .useSelector */ .v9)((state)=>state.customizer);
    const dispatch = (0,_store_Store__WEBPACK_IMPORTED_MODULE_4__/* .useDispatch */ .I0)();
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
    const toggleWidth = customizer.isCollapse && !customizer.isSidebarHover ? customizer.MiniSidebarWidth : customizer.SidebarWidth;
    const onHoverEnter = ()=>{
        if (customizer.isCollapse) {
            dispatch((0,_store_customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_5__/* .hoverSidebar */ .bR)(true));
        }
    };
    const onHoverLeave = ()=>{
        dispatch((0,_store_customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_5__/* .hoverSidebar */ .bR)(false));
    };
    if (lgUp) {
        return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
            sx: {
                width: toggleWidth,
                flexShrink: 0,
                ...customizer.isCollapse && {
                    position: "absolute"
                }
            },
            children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Drawer, {
                anchor: "left",
                open: true,
                onMouseEnter: onHoverEnter,
                onMouseLeave: onHoverLeave,
                variant: "permanent",
                PaperProps: {
                    sx: {
                        transition: theme.transitions.create("width", {
                            duration: theme.transitions.duration.shortest
                        }),
                        width: toggleWidth,
                        boxSizing: "border-box"
                    }
                },
                children: /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                    sx: {
                        height: "100%"
                    },
                    children: [
                        /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                            px: 3,
                            children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_shared_logo_Logo__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
                        }),
                        /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_custom_scroll_Scrollbar__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                            sx: {
                                height: "calc(100% - 190px)"
                            },
                            children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SidebarItems__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
                        }),
                        /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SidebarProfile_Profile__WEBPACK_IMPORTED_MODULE_7__/* .Profile */ .N, {})
                    ]
                })
            })
        });
    }
    return /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Drawer, {
        anchor: "left",
        open: customizer.isMobileSidebar,
        onClose: ()=>dispatch((0,_store_customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_5__/* .toggleMobileSidebar */ .tW)()),
        variant: "temporary",
        PaperProps: {
            sx: {
                width: customizer.SidebarWidth,
                // backgroundColor:
                //   customizer.activeMode === 'dark'
                //     ? customizer.darkBackground900
                //     : customizer.activeSidebarBg,
                // color: customizer.activeSidebarBg === '#ffffff' ? '' : 'white',
                border: "0 !important",
                boxShadow: (theme)=>theme.shadows[8]
            }
        },
        children: [
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                px: 2,
                children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_shared_logo_Logo__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
            }),
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SidebarItems__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Sidebar);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3476:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var _MenuItems__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3130);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _store_Store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7404);
/* harmony import */ var _NavItem__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2060);
/* harmony import */ var _NavCollapse__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4344);
/* harmony import */ var _NavGroup_NavGroup__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2429);
/* harmony import */ var _store_customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9065);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _store_Store__WEBPACK_IMPORTED_MODULE_4__, _NavItem__WEBPACK_IMPORTED_MODULE_5__, _NavCollapse__WEBPACK_IMPORTED_MODULE_6__, _NavGroup_NavGroup__WEBPACK_IMPORTED_MODULE_7__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _store_Store__WEBPACK_IMPORTED_MODULE_4__, _NavItem__WEBPACK_IMPORTED_MODULE_5__, _NavCollapse__WEBPACK_IMPORTED_MODULE_6__, _NavGroup_NavGroup__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const SidebarItems = ()=>{
    const { pathname  } = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const pathDirect = pathname;
    const pathWithoutLastPart = pathname.slice(0, pathname.lastIndexOf("/"));
    const customizer = (0,_store_Store__WEBPACK_IMPORTED_MODULE_4__/* .useSelector */ .v9)((state)=>state.customizer);
    const lgUp = (0,_mui_material__WEBPACK_IMPORTED_MODULE_3__.useMediaQuery)((theme)=>theme.breakpoints.up("lg"));
    const hideMenu = lgUp ? customizer.isCollapse && !customizer.isSidebarHover : "";
    const dispatch = (0,_store_Store__WEBPACK_IMPORTED_MODULE_4__/* .useDispatch */ .I0)();
    return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
        sx: {
            px: 3
        },
        children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.List, {
            sx: {
                pt: 0
            },
            className: "sidebarNav",
            children: _MenuItems__WEBPACK_IMPORTED_MODULE_1__/* ["default"].map */ .Z.map((item)=>{
                // {/********SubHeader**********/}
                if (item.subheader) {
                    return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_NavGroup_NavGroup__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        item: item,
                        hideMenu: hideMenu
                    }, item.subheader);
                // {/********If Sub Menu**********/}
                /* eslint no-else-return: "off" */ } else if (item.children) {
                    return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_NavCollapse__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        menu: item,
                        pathDirect: pathDirect,
                        hideMenu: hideMenu,
                        pathWithoutLastPart: pathWithoutLastPart,
                        level: 1,
                        onClick: ()=>dispatch((0,_store_customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_8__/* .toggleMobileSidebar */ .tW)())
                    }, item.id);
                // {/********If Sub No Menu**********/}
                } else {
                    return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_NavItem__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        item: item,
                        pathDirect: pathDirect,
                        hideMenu: hideMenu,
                        onClick: ()=>dispatch((0,_store_customizer_CustomizerSlice__WEBPACK_IMPORTED_MODULE_8__/* .toggleMobileSidebar */ .tW)())
                    }, item.id);
                }
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SidebarItems);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4149:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "N": () => (/* binding */ Profile)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _store_Store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7404);
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2236);
/* harmony import */ var _tabler_icons_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7987);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _store_Store__WEBPACK_IMPORTED_MODULE_2__, react_i18next__WEBPACK_IMPORTED_MODULE_4__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _store_Store__WEBPACK_IMPORTED_MODULE_2__, react_i18next__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const Profile = ()=>{
    const customizer = (0,_store_Store__WEBPACK_IMPORTED_MODULE_2__/* .useSelector */ .v9)((state)=>state.customizer);
    const lgUp = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)((theme)=>theme.breakpoints.up("lg"));
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
    const hideMenu = lgUp ? customizer.isCollapse && !customizer.isSidebarHover : "";
    return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
        display: "flex",
        alignItems: "center",
        gap: 2,
        sx: {
            m: 3,
            p: 2,
            bgcolor: `${"secondary.light"}`
        },
        children: !hideMenu ? /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Avatar, {
                    alt: "Remy Sharp",
                    src: "/images/profile/user-1.jpg",
                    sx: {
                        height: 40,
                        width: 40
                    }
                }),
                /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                    children: [
                        /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                            variant: "h6",
                            children: "Sonia"
                        }),
                        /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                            variant: "caption",
                            children: t(`${"Costemologist"}`)
                        })
                    ]
                }),
                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                    sx: {
                        ml: "auto"
                    },
                    children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Tooltip, {
                        title: "Logout",
                        placement: "top",
                        children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.IconButton, {
                            color: "primary",
                            // component={Link}
                            onClick: ()=>{
                                if (false) {}
                            },
                            // href="/auth/auth1/login"
                            "aria-label": "logout",
                            size: "small",
                            children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons_react__WEBPACK_IMPORTED_MODULE_3__.IconPower, {
                                size: "20"
                            })
                        })
                    })
                })
            ]
        }) : ""
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2541:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _DefaultColors__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7584);
// project imports

const components = (theme)=>{
    return {
        MuiCssBaseline: {
            styleOverrides: {
                "*": {
                    boxSizing: "border-box"
                },
                html: {
                    height: "100%",
                    width: "100%"
                },
                a: {
                    textDecoration: "none"
                },
                body: {
                    height: "100%",
                    margin: 0,
                    padding: 0
                },
                "#root": {
                    height: "100%"
                },
                "*[dir='rtl'] .buyNowImg": {
                    transform: "scaleX(-1)"
                },
                ".border-none": {
                    border: "0px",
                    td: {
                        border: "0px"
                    }
                },
                ".btn-xs": {
                    minWidth: "30px !important",
                    width: "30px",
                    height: "30px",
                    borderRadius: "6px !important",
                    padding: "0px !important"
                },
                ".hover-text-primary:hover .text-hover": {
                    color: theme.palette.primary.main
                },
                ".hoverCard:hover": {
                    scale: "1.01",
                    transition: " 0.1s ease-in"
                },
                ".signup-bg": {
                    position: "absolute",
                    top: 0,
                    right: 0,
                    height: "100%"
                },
                ".MuiBox-root": {
                    borderRadius: theme.shape.borderRadius
                },
                ".MuiCardHeader-action": {
                    alignSelf: "center !important"
                },
                ".emoji-picker-react .emoji-scroll-wrapper": {
                    overflowX: "hidden"
                },
                ".scrollbar-container": {
                    borderRight: "0 !important"
                },
                ".theme-timeline .MuiTimelineOppositeContent-root": {
                    minWidth: "90px"
                },
                ".MuiAlert-root .MuiAlert-icon": {
                    color: "inherit!important"
                },
                ".MuiTimelineConnector-root": {
                    width: "1px !important"
                },
                " .simplebar-scrollbar:before": {
                    background: `${theme.palette.grey[300]} !important`
                },
                "@keyframes gradient": {
                    "0%": {
                        backgroundPosition: "0% 50%"
                    },
                    "50%": {
                        backgroundPosition: " 100% 50%"
                    },
                    "100% ": {
                        backgroundPosition: " 0% 50%"
                    }
                }
            }
        },
        MuiButtonGroup: {
            styleOverrides: {
                root: {
                    boxShadow: "none"
                }
            }
        },
        MuiAccordion: {
            styleOverrides: {
                root: {
                    ":before": {
                        backgroundColor: theme.palette.grey[100]
                    }
                }
            }
        },
        MuiPaper: {
            styleOverrides: {
                root: {
                    // border: `1px solid ${theme.palette.divider}`,
                    backgroundImage: "none"
                }
            }
        },
        MuiStepConnector: {
            styleOverrides: {
                line: {
                    borderColor: theme.palette.divider
                }
            }
        },
        MuiFab: {
            styleOverrides: {
                root: {
                    boxShadow: "none"
                },
                sizeSmall: {
                    width: 30,
                    height: 30,
                    minHeight: 30
                }
            }
        },
        MuiButton: {
            styleOverrides: {
                root: {
                    textTransform: "none",
                    boxShadow: "none"
                },
                text: {
                    padding: "5px 15px"
                },
                textPrimary: {
                    backgroundColor: theme.palette.primary.light,
                    "&:hover": {
                        backgroundColor: theme.palette.primary.main,
                        color: "white"
                    }
                },
                textSecondary: {
                    backgroundColor: theme.palette.secondary.light,
                    "&:hover": {
                        backgroundColor: theme.palette.secondary.main,
                        color: "white"
                    }
                },
                textSuccess: {
                    backgroundColor: theme.palette.success.light,
                    "&:hover": {
                        backgroundColor: theme.palette.success.main,
                        color: "white"
                    }
                },
                textError: {
                    backgroundColor: theme.palette.error.light,
                    "&:hover": {
                        backgroundColor: theme.palette.error.main,
                        color: "white"
                    }
                },
                textInfo: {
                    backgroundColor: theme.palette.info.light,
                    "&:hover": {
                        backgroundColor: theme.palette.info.main,
                        color: "white"
                    }
                },
                textWarning: {
                    backgroundColor: theme.palette.warning.light,
                    "&:hover": {
                        backgroundColor: theme.palette.warning.main,
                        color: "white"
                    }
                },
                outlinedPrimary: {
                    "&:hover": {
                        backgroundColor: theme.palette.primary.main,
                        color: "white"
                    }
                },
                outlinedSecondary: {
                    "&:hover": {
                        backgroundColor: theme.palette.secondary.main,
                        color: "white"
                    }
                },
                outlinedError: {
                    "&:hover": {
                        backgroundColor: theme.palette.error.main,
                        color: "white"
                    }
                },
                outlinedSuccess: {
                    "&:hover": {
                        backgroundColor: theme.palette.success.main,
                        color: "white"
                    }
                },
                outlinedInfo: {
                    "&:hover": {
                        backgroundColor: theme.palette.info.main,
                        color: "white"
                    }
                },
                outlinedWarning: {
                    "&:hover": {
                        backgroundColor: theme.palette.warning.main,
                        color: "white"
                    }
                }
            }
        },
        MuiCardHeader: {
            styleOverrides: {
                root: {
                    padding: "16px 24px"
                },
                title: {
                    fontSize: "1.125rem"
                }
            }
        },
        MuiCard: {
            styleOverrides: {
                root: {
                    width: "100%",
                    padding: "15px",
                    backgroundImage: "none"
                }
            }
        },
        MuiCardContent: {
            styleOverrides: {
                root: {
                    padding: "24px"
                }
            }
        },
        MuiTableCell: {
            styleOverrides: {
                root: {
                    borderBottom: `1px solid ${theme.palette.divider}`
                }
            }
        },
        MuiTableRow: {
            styleOverrides: {
                root: {
                    "&:last-child td": {
                        borderBottom: 0
                    }
                }
            }
        },
        MuiGridItem: {
            styleOverrides: {
                root: {
                    paddingTop: "30px",
                    paddingLeft: "30px !important"
                }
            }
        },
        MuiLinearProgress: {
            styleOverrides: {
                root: {
                    backgroundColor: theme.palette.grey[200],
                    borderRadius: "6px"
                }
            }
        },
        MuiTimelineConnector: {
            styleOverrides: {
                root: {
                    backgroundColor: theme.palette.divider
                }
            }
        },
        MuiDivider: {
            styleOverrides: {
                root: {
                    borderColor: theme.palette.divider
                }
            }
        },
        MuiChip: {
            styleOverrides: {
                root: {
                    fontWeight: 600,
                    fontSize: "0.75rem"
                }
            }
        },
        MuiAlert: {
            styleOverrides: {
                filledSuccess: {
                    color: "white"
                },
                filledInfo: {
                    color: "white"
                },
                filledError: {
                    color: "white"
                },
                filledWarning: {
                    color: "white"
                },
                standardSuccess: {
                    backgroundColor: theme.palette.success.light,
                    color: theme.palette.success.main
                },
                standardError: {
                    backgroundColor: theme.palette.error.light,
                    color: theme.palette.error.main
                },
                standardWarning: {
                    backgroundColor: theme.palette.warning.light,
                    color: theme.palette.warning.main
                },
                standardInfo: {
                    backgroundColor: theme.palette.info.light,
                    color: theme.palette.info.main
                },
                outlinedSuccess: {
                    borderColor: theme.palette.success.main,
                    color: theme.palette.success.main
                },
                outlinedWarning: {
                    borderColor: theme.palette.warning.main,
                    color: theme.palette.warning.main
                },
                outlinedError: {
                    borderColor: theme.palette.error.main,
                    color: theme.palette.error.main
                },
                outlinedInfo: {
                    borderColor: theme.palette.info.main,
                    color: theme.palette.info.main
                },
                successIcon: {
                    color: theme.palette.info.main
                }
            }
        },
        MuiOutlinedInput: {
            styleOverrides: {
                root: {
                    "& .MuiOutlinedInput-notchedOutline": {
                        borderColor: theme.palette.mode === "dark" ? theme.palette.grey[200] : theme.palette.grey[300]
                    },
                    "&:hover .MuiOutlinedInput-notchedOutline": {
                        borderColor: theme.palette.grey[300]
                    }
                },
                input: {
                    padding: "12px 14px"
                },
                inputSizeSmall: {
                    padding: "8px 14px"
                }
            }
        },
        MuiTooltip: {
            styleOverrides: {
                tooltip: {
                    color: theme.palette.background.paper,
                    background: theme.palette.text.primary
                }
            }
        },
        MuiDrawer: {
            styleOverrides: {
                paper: {
                    borderColor: `${theme.palette.divider}`
                }
            }
        },
        MuiDialogTitle: {
            styleOverrides: {
                root: {
                    fontSize: "1.25rem"
                }
            }
        },
        MuiPopover: {
            styleOverrides: {
                paper: {
                    boxShadow: "rgb(145 158 171 / 30%) 0px 0px 2px 0px, rgb(145 158 171 / 12%) 0px 12px 24px -4px"
                }
            }
        }
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (components);


/***/ }),

/***/ 4798:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r": () => (/* binding */ DarkThemeColors)
/* harmony export */ });
const DarkThemeColors = [
    {
        name: "BLUE_THEME",
        palette: {
            primary: {
                main: "#5D87FF",
                light: "#253662",
                dark: "#4570EA",
                contrastText: "#ffffff"
            },
            secondary: {
                main: "#49BEFF",
                light: "#1C455D",
                dark: "#23afdb",
                contrastText: "#ffffff"
            },
            background: {
                default: "#2A3447",
                dark: "#2A3547",
                paper: "#2A3447"
            }
        }
    },
    {
        name: "AQUA_THEME",
        palette: {
            primary: {
                main: "#0074BA",
                light: "#103247",
                dark: "#006DAF",
                contrastText: "#ffffff"
            },
            secondary: {
                main: "#47D7BC",
                light: "#0C4339",
                dark: "#39C7AD",
                contrastText: "#ffffff"
            }
        }
    },
    {
        name: "PURPLE_THEME",
        palette: {
            primary: {
                main: "#763EBD",
                light: "#26153C",
                dark: "#6E35B7",
                contrastText: "#ffffff"
            },
            secondary: {
                main: "#95CFD5",
                light: "#09454B",
                dark: "#8BC8CE",
                contrastText: "#ffffff"
            }
        }
    },
    {
        name: "GREEN_THEME",
        palette: {
            primary: {
                main: "#0A7EA4",
                light: "#05313F",
                dark: "#06769A",
                contrastText: "#ffffff"
            },
            secondary: {
                main: "#CCDA4E",
                light: "#282917",
                dark: "#C3D046",
                contrastText: "#ffffff"
            }
        }
    },
    {
        name: "CYAN_THEME",
        palette: {
            primary: {
                main: "#01C0C8",
                light: "#003638",
                dark: "#00B9C0",
                contrastText: "#ffffff"
            },
            secondary: {
                main: "#FB9678",
                light: "#40241C",
                dark: "#F48B6C",
                contrastText: "#ffffff"
            }
        }
    },
    {
        name: "ORANGE_THEME",
        palette: {
            primary: {
                main: "#FA896B",
                light: "#402E32",
                dark: "#F48162",
                contrastText: "#ffffff"
            },
            secondary: {
                main: "#0074BA",
                light: "#082E45",
                dark: "#006FB1",
                contrastText: "#ffffff"
            }
        }
    }
];



/***/ }),

/***/ 7584:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A": () => (/* binding */ baseDarkTheme),
/* harmony export */   "e": () => (/* binding */ baselightTheme)
/* harmony export */ });
const baselightTheme = {
    direction: "ltr",
    palette: {
        primary: {
            main: "#5D87FF",
            light: "#ECF2FF",
            dark: "#4570EA"
        },
        secondary: {
            main: "#49BEFF",
            light: "#E8F7FF",
            dark: "#23afdb"
        },
        success: {
            main: "#13DEB9",
            light: "#E6FFFA",
            dark: "#02b3a9",
            contrastText: "#ffffff"
        },
        info: {
            main: "#539BFF",
            light: "#EBF3FE",
            dark: "#1682d4",
            contrastText: "#ffffff"
        },
        error: {
            main: "#FA896B",
            light: "#FDEDE8",
            dark: "#f3704d",
            contrastText: "#ffffff"
        },
        warning: {
            main: "#FFAE1F",
            light: "#FEF5E5",
            dark: "#ae8e59",
            contrastText: "#ffffff"
        },
        purple: {
            A50: "#EBF3FE",
            A100: "#6610f2",
            A200: "#557fb9"
        },
        grey: {
            100: "#F2F6FA",
            200: "#EAEFF4",
            300: "#DFE5EF",
            400: "#7C8FAC",
            500: "#5A6A85",
            600: "#2A3547"
        },
        text: {
            primary: "#2A3547",
            secondary: "#2A3547"
        },
        action: {
            disabledBackground: "rgba(73,82,88,0.12)",
            hoverOpacity: 0.02,
            hover: "#f6f9fc"
        },
        divider: "#e5eaef"
    }
};
const baseDarkTheme = {
    direction: "ltr",
    palette: {
        primary: {
            main: "#5D87FF",
            light: "#ECF2FF",
            dark: "#4570EA"
        },
        secondary: {
            main: "#777e89",
            light: "#1C455D",
            dark: "#173f98"
        },
        success: {
            main: "#13DEB9",
            light: "#1B3C48",
            dark: "#02b3a9",
            contrastText: "#ffffff"
        },
        info: {
            main: "#539BFF",
            light: "#223662",
            dark: "#1682d4",
            contrastText: "#ffffff"
        },
        error: {
            main: "#FA896B",
            light: "#4B313D",
            dark: "#f3704d",
            contrastText: "#ffffff"
        },
        warning: {
            main: "#FFAE1F",
            light: "#4D3A2A",
            dark: "#ae8e59",
            contrastText: "#ffffff"
        },
        purple: {
            A50: "#EBF3FE",
            A100: "#6610f2",
            A200: "#557fb9"
        },
        grey: {
            100: "#333F55",
            200: "#465670",
            300: "#7C8FAC",
            400: "#DFE5EF",
            500: "#EAEFF4",
            600: "#F2F6FA"
        },
        text: {
            primary: "#EAEFF4",
            secondary: "#7C8FAC"
        },
        action: {
            disabledBackground: "rgba(73,82,88,0.12)",
            hoverOpacity: 0.02,
            hover: "#333F55"
        },
        divider: "#333F55",
        background: {
            default: "#171c23",
            dark: "#171c23",
            paper: "#171c23"
        }
    }
};



/***/ }),

/***/ 2058:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ LightThemeColors)
/* harmony export */ });
const LightThemeColors = [
    {
        name: "BLUE_THEME",
        palette: {
            primary: {
                main: "#5D87FF",
                light: "#ECF2FF",
                dark: "#4570EA",
                contrastText: "#ffffff"
            },
            secondary: {
                main: "#49BEFF",
                light: "#E8F7FF",
                dark: "#23afdb",
                contrastText: "#ffffff"
            }
        }
    },
    {
        name: "AQUA_THEME",
        palette: {
            primary: {
                main: "#0074BA",
                light: "#EFF9FF",
                dark: "#006DAF",
                contrastText: "#ffffff"
            },
            secondary: {
                main: "#47D7BC",
                light: "#EDFBF7",
                dark: "#39C7AD",
                contrastText: "#ffffff"
            }
        }
    },
    {
        name: "PURPLE_THEME",
        palette: {
            primary: {
                main: "#763EBD",
                light: "#F2ECF9",
                dark: "#6E35B7",
                contrastText: "#ffffff"
            },
            secondary: {
                main: "#95CFD5",
                light: "#EDF8FA",
                dark: "#8BC8CE",
                contrastText: "#ffffff"
            }
        }
    },
    {
        name: "GREEN_THEME",
        palette: {
            primary: {
                main: "#0A7EA4",
                light: "#F4F9FB",
                dark: "#06769A",
                contrastText: "#ffffff"
            },
            secondary: {
                main: "#CCDA4E",
                light: "#FAFBEF",
                dark: "#C3D046",
                contrastText: "#ffffff"
            }
        }
    },
    {
        name: "CYAN_THEME",
        palette: {
            primary: {
                main: "#01C0C8",
                light: "#EBF9FA",
                dark: "#00B9C0",
                contrastText: "#ffffff"
            },
            secondary: {
                main: "#FB9678",
                light: "#FFF5F2",
                dark: "#F48B6C",
                contrastText: "#ffffff"
            }
        }
    },
    {
        name: "ORANGE_THEME",
        palette: {
            primary: {
                main: "#FA896B",
                light: "#FBF2EF",
                dark: "#F48162",
                contrastText: "#ffffff"
            },
            secondary: {
                main: "#0074BA",
                light: "#EFF9FF",
                dark: "#006FB1",
                contrastText: "#ffffff"
            }
        }
    }
];



/***/ }),

/***/ 4252:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ darkshadows),
/* harmony export */   "q": () => (/* binding */ shadows)
/* harmony export */ });
const shadows = [
    "none",
    "0px 2px 3px rgba(0,0,0,0.10)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 2px 2px -2px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 3px 4px -2px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 3px 4px -2px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 4px 6px -2px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 4px 6px -2px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 4px 8px -2px rgba(0,0,0,0.25)",
    "0 9px 17.5px rgb(0,0,0,0.05)",
    "rgb(145 158 171 / 30%) 0px 0px 2px 0px, rgb(145 158 171 / 12%) 0px 12px 24px -4px",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 7px 12px -4px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 6px 16px -4px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 7px 16px -4px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 8px 18px -8px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 9px 18px -8px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 10px 20px -8px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 11px 20px -8px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 12px 22px -8px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 13px 22px -8px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 14px 24px -8px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 16px 28px -8px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 18px 30px -8px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 20px 32px -8px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 22px 34px -8px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 24px 36px -8px rgba(0,0,0,0.25)"
];
const darkshadows = [
    "none",
    "0px 2px 3px rgba(0,0,0,0.10)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 2px 2px -2px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 3px 4px -2px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 3px 4px -2px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 4px 6px -2px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 4px 6px -2px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 4px 8px -2px rgba(0,0,0,0.25)",
    "0 9px 17.5px rgb(0,0,0,0.05)",
    "rgb(145 158 171 / 30%) 0px 0px 2px 0px, rgb(145 158 171 / 2%) 0px 12px 24px -4px",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 7px 12px -4px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 6px 16px -4px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 7px 16px -4px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 8px 18px -8px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 9px 18px -8px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 10px 20px -8px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 11px 20px -8px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 12px 22px -8px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 13px 22px -8px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 14px 24px -8px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 16px 28px -8px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 18px 30px -8px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 20px 32px -8px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 22px 34px -8px rgba(0,0,0,0.25)",
    "0 0 1px 0 rgba(0,0,0,0.31), 0 24px 36px -8px rgba(0,0,0,0.25)"
];



/***/ }),

/***/ 9260:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "f": () => (/* binding */ ThemeSettings)
/* harmony export */ });
/* unused harmony export BuildTheme */
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6517);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _store_Store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7404);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2541);
/* harmony import */ var _Typography__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(235);
/* harmony import */ var _Shadows__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4252);
/* harmony import */ var _DarkThemeColors__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4798);
/* harmony import */ var _LightThemeColors__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2058);
/* harmony import */ var _DefaultColors__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7584);
/* harmony import */ var _mui_material_locale__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2311);
/* harmony import */ var _mui_material_locale__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material_locale__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_store_Store__WEBPACK_IMPORTED_MODULE_2__]);
_store_Store__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];











const BuildTheme = (config = {})=>{
    const themeOptions = _LightThemeColors__WEBPACK_IMPORTED_MODULE_7__/* .LightThemeColors.find */ .z.find((theme)=>theme.name === config.theme);
    const darkthemeOptions = _DarkThemeColors__WEBPACK_IMPORTED_MODULE_6__/* .DarkThemeColors.find */ .r.find((theme)=>theme.name === config.theme);
    const customizer = (0,_store_Store__WEBPACK_IMPORTED_MODULE_2__/* .useSelector */ .v9)((state)=>state.customizer);
    const defaultTheme = customizer.activeMode === "dark" ? _DefaultColors__WEBPACK_IMPORTED_MODULE_8__/* .baseDarkTheme */ .A : _DefaultColors__WEBPACK_IMPORTED_MODULE_8__/* .baselightTheme */ .e;
    const defaultShadow = customizer.activeMode === "dark" ? _Shadows__WEBPACK_IMPORTED_MODULE_10__/* .darkshadows */ .a : _Shadows__WEBPACK_IMPORTED_MODULE_10__/* .shadows */ .q;
    const themeSelect = customizer.activeMode === "dark" ? darkthemeOptions : themeOptions;
    const baseMode = {
        palette: {
            mode: customizer.activeMode
        },
        shape: {
            borderRadius: customizer.borderRadius
        },
        shadows: defaultShadow,
        typography: _Typography__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z
    };
    const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__.createTheme)(lodash__WEBPACK_IMPORTED_MODULE_0___default().merge({}, baseMode, defaultTheme, _mui_material_locale__WEBPACK_IMPORTED_MODULE_9__, themeSelect, {
        direction: config.direction
    }));
    theme.components = (0,_Components__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)(theme);
    return theme;
};
const ThemeSettings = ()=>{
    const activDir = (0,_store_Store__WEBPACK_IMPORTED_MODULE_2__/* .useSelector */ .v9)((state)=>state.customizer.activeDir);
    const activeTheme = (0,_store_Store__WEBPACK_IMPORTED_MODULE_2__/* .useSelector */ .v9)((state)=>state.customizer.activeTheme);
    const theme = BuildTheme({
        direction: activDir,
        theme: activeTheme
    });
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        document.dir = activDir;
    }, [
        activDir
    ]);
    return theme;
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 235:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const typography = {
    fontFamily: "'Plus Jakarta Sans', sans-serif;",
    h1: {
        fontWeight: 600,
        fontSize: "2.25rem",
        lineHeight: "2.75rem"
    },
    h2: {
        fontWeight: 600,
        fontSize: "1.875rem",
        lineHeight: "2.25rem"
    },
    h3: {
        fontWeight: 600,
        fontSize: "1.5rem",
        lineHeight: "1.75rem"
    },
    h4: {
        fontWeight: 600,
        fontSize: "1.3125rem",
        lineHeight: "1.6rem"
    },
    h5: {
        fontWeight: 600,
        fontSize: "1.125rem",
        lineHeight: "1.6rem"
    },
    h6: {
        fontWeight: 600,
        fontSize: "1rem",
        lineHeight: "1.2rem"
    },
    button: {
        textTransform: "capitalize",
        fontWeight: 400
    },
    body1: {
        fontSize: "0.875rem",
        fontWeight: 400,
        lineHeight: "1.334rem"
    },
    body2: {
        fontSize: "0.75rem",
        letterSpacing: "0rem",
        fontWeight: 400,
        lineHeight: "1rem"
    },
    subtitle1: {
        fontSize: "0.875rem",
        fontWeight: 400
    },
    subtitle2: {
        fontSize: "0.875rem",
        fontWeight: 400
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (typography);


/***/ }),

/***/ 6934:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2021);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7987);
/* harmony import */ var _utils_languages_en_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8047);
/* harmony import */ var _utils_languages_es_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(671);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([i18next__WEBPACK_IMPORTED_MODULE_0__, react_i18next__WEBPACK_IMPORTED_MODULE_1__]);
([i18next__WEBPACK_IMPORTED_MODULE_0__, react_i18next__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const resources = {
    en: {
        translation: _utils_languages_en_json__WEBPACK_IMPORTED_MODULE_2__
    },
    // fr: {
    //   translation: french,
    // },
    // ar: {
    //   translation: arabic,
    // },
    // ch: {
    //   translation: chinese,
    // },
    es: {
        translation: _utils_languages_es_json__WEBPACK_IMPORTED_MODULE_3__
    }
};
i18next__WEBPACK_IMPORTED_MODULE_0__["default"].use(react_i18next__WEBPACK_IMPORTED_MODULE_1__.initReactI18next) // passes i18n down to react-i18next
.init({
    resources,
    lng: "en",
    interpolation: {
        escapeValue: false
    }
});
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (i18n)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1791:
/***/ (() => {



/***/ }),

/***/ 8710:
/***/ (() => {



/***/ }),

/***/ 782:
/***/ (() => {



/***/ }),

/***/ 8278:
/***/ (() => {



/***/ }),

/***/ 245:
/***/ (() => {



/***/ }),

/***/ 1913:
/***/ ((module) => {

"use strict";
module.exports = require("@emotion/cache");

/***/ }),

/***/ 7915:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material");

/***/ }),

/***/ 5645:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/AspectRatioTwoTone");

/***/ }),

/***/ 1021:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/CallToActionTwoTone");

/***/ }),

/***/ 8408:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/DarkModeTwoTone");

/***/ }),

/***/ 9635:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/SwipeLeftAltTwoTone");

/***/ }),

/***/ 8193:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/SwipeRightAltTwoTone");

/***/ }),

/***/ 5580:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/ViewSidebarTwoTone");

/***/ }),

/***/ 3742:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/WbSunnyTwoTone");

/***/ }),

/***/ 1349:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/WebAssetTwoTone");

/***/ }),

/***/ 5692:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material");

/***/ }),

/***/ 19:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Box");

/***/ }),

/***/ 4960:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/CssBaseline");

/***/ }),

/***/ 2311:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/locale");

/***/ }),

/***/ 8442:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/styles");

/***/ }),

/***/ 7986:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system");

/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2236:
/***/ ((module) => {

"use strict";
module.exports = require("@tabler/icons-react");

/***/ }),

/***/ 6963:
/***/ ((module) => {

"use strict";
module.exports = require("axios-mock-adapter");

/***/ }),

/***/ 4146:
/***/ ((module) => {

"use strict";
module.exports = require("date-fns");

/***/ }),

/***/ 6517:
/***/ ((module) => {

"use strict";
module.exports = require("lodash");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 6695:
/***/ ((module) => {

"use strict";
module.exports = require("redux");

/***/ }),

/***/ 4172:
/***/ ((module) => {

"use strict";
module.exports = require("simplebar-react");

/***/ }),

/***/ 3195:
/***/ ((module) => {

"use strict";
module.exports = require("stylis-plugin-rtl");

/***/ }),

/***/ 3139:
/***/ ((module) => {

"use strict";
module.exports = import("@emotion/react");;

/***/ }),

/***/ 7101:
/***/ ((module) => {

"use strict";
module.exports = import("@emotion/react/jsx-runtime");;

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 2021:
/***/ ((module) => {

"use strict";
module.exports = import("i18next");;

/***/ }),

/***/ 7987:
/***/ ((module) => {

"use strict";
module.exports = import("react-i18next");;

/***/ }),

/***/ 8047:
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('{"Starter":"Starter","Home":"Home","Menu Level":"Menu Level","Disabled":"Disabled","SubCaption":"SubCaption","Chip":"Chip","Outlined":"Outlined","External Link":"External Link","Register":"Register","List":"List","Costemologist":"Costemologist","Patient Register":"Patients Register","Patients List":"Patients List","Patients":"Patients","Patient":"Patient","Patient Information":"Patient Information","Patient has successfully registered":"Patient has successfully registered","Phone":"Phone","Adress":"Adress","Budget":"Budget","Status":"Status","Person Info":"Person Info","First Name":"First Name","Last Name":"Last Name","Select Gender":"Select Gender","Date of Birth":"Date of Birth","Marital Status":"Marital Status","Religion":"Religion","Ocupation":"Ocupation","Blod Type":"Blod Type","Address":"Address","Street":"Street","City":"City","State":"State","Post Code":"Post Code","Country":"Country","Contact Information":"Contact Information","Email":"Email","Phone Number":"Phone Number","Emergency Phone Number":"Emergency Phone Number"}');

/***/ }),

/***/ 671:
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('{"Starter":"Inicio","Home":"Inicio","Menu Level":"Niveles menu","Disabled":"Desabilitado","SubCaption":"SubTitulo","Chip":"Chip","Outlined":"Fuera de linea","External Link":"Link Externo","Register":"Registrar","List":"Lista","Costemologist":"Cosmetologa","Patients":"Pacientes","Patient":"Paciente","Patient Register":"Registrar Paciente","Patients List":"Lista de Pacientes","Patient Information":"Información de paciente","Patient has successfully registered":"Paciente regristrado exitosamente","Phone":"Telefono","Adress":"Dirección","Budget":"Presupuesto","Status":"Estatus","Person Info":"Iformación personal","First Name":"Nombre","Last Name":"Apellido","Select Gender":"Genero","Date of Birth":"Fecha de nacimiento","Marital Status":"Estado civil","Religion":"Religión","Ocupation":"Ocupación","Blod Type":"Tipo de sangre","Address":"Dirección","Street":"Calle","City":"Ciudad","State":"Estado","Post Code":"Codigo Postal","Country":"Pais","Contact Information":"Información de contacto","Email":"Correo","Phone Number":"Numero de telefono","Emergency Phone Number":"Numero de emergencia"}');

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [210,676,664,121,675,404,95], () => (__webpack_exec__(3847)));
module.exports = __webpack_exports__;

})();