# Doctor2Doctor

Doctor to Doctor is a React app for cosmetic services.

## Installation

- Yo need npm

```bash
npm install
```

## Run

```bash
npm run dev
```
