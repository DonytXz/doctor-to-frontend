import mock from './mock';

mock.onAny().passThrough();
