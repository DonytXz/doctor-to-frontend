export const handleChangeGeneric = (value: any, setState: any) => {
  setState(value);
};
