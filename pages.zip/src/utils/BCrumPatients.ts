export const BCrumPatients = [
  {
    to: "/patients/list",
    title: "Patients List",
  },
  {
    to: "/patients/register",
    title: "Patient Register",
  },
];