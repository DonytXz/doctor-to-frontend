export const BCrumProceedings = [
  {
    to: "/proceedings",
    title: "Create Proceedings",
  },
];
